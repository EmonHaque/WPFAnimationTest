﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    public class RoundButton : FrameworkElement
    {
        double square;
        Size size;
        VisualCollection children;
        RoundEllipse ellipse;
        Path pathIcon, ripplePath, arc;
        EllipseGeometry rippleEllipse;
        SolidColorBrush pathIconBrush;
        ColorAnimation pathIconAnim;
        DoubleAnimation rippleAnim, arcRotateAnim;
        DropShadowEffect effect;
        RotateTransform arcRoateTransform;
        AnimationClock arcRotateClock;

        public RoundButton(double square) {
            this.square = square;
            size = new Size(square, square);
            children = new VisualCollection(this);
            ellipse = new RoundEllipse();

            pathIconBrush = new SolidColorBrush(Colors.Gray);
            pathIcon = new Path() {
                Width = size.Width / 4 * 3,
                Height = size.Height / 4 * 3,
                Fill = pathIconBrush,
                Stretch = Stretch.Uniform
            };
            rippleEllipse = new EllipseGeometry();
            ripplePath = new Path() {
                Fill = new SolidColorBrush(Color.FromArgb(50, 0, 255, 0)),
                Data = rippleEllipse,
                Clip = new EllipseGeometry(new Point(size.Width/2, size.Height/2), size.Width / 2, size.Height / 2)
            };
            arcRoateTransform = new RotateTransform() { CenterX = size.Width / 2, CenterY = size.Height / 2 };
            arc = new Path() {
                Visibility = Visibility.Hidden,
                RenderTransform = arcRoateTransform,
                Stroke = Brushes.Coral,
                StrokeThickness = 6,
                Data = new PathGeometry() {
                    Figures = {
                        new PathFigure() {
                            StartPoint = new Point(2, size.Height/2),
                            IsClosed = false,
                            Segments = {
                                new ArcSegment() {
                                    Point = new Point(size.Width - 2, size.Height/2),
                                    Size = new Size(1, 1),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
                }
            };
            children.Add(pathIcon);
            children.Add(ripplePath);
            children.Add(arc);
           
            pathIconAnim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            rippleAnim = new DoubleAnimation() {
                From = 0,
                To = size.Width,
                FillBehavior = FillBehavior.Stop,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            arcRotateAnim = new DoubleAnimation() {
                By = 5,
                IsCumulative = true,
                RepeatBehavior = RepeatBehavior.Forever,
                Duration = TimeSpan.FromSeconds(0.01)
            };
            arcRotateClock = arcRotateAnim.CreateClock();
            arcRoateTransform.ApplyAnimationClock(RotateTransform.AngleProperty, arcRotateClock);
            effect = new DropShadowEffect() { BlurRadius = 30, ShadowDepth = 0 };
        }

        void resetButton(object sender, EventArgs e) {
            if (Command.CanExecute(null)) {
                IsEnabled = true;
                Effect = effect;
            }
            else {
                IsEnabled = false;
                Effect = null;
            }
        }

        protected override Size MeasureOverride(Size availableSize) => size;
        protected override Size ArrangeOverride(Size finalSize) {
            var icon = children[0] as Path;
            icon.Measure(size);
            icon.Arrange(new Rect(new Point(size.Width/8, size.Height/8), icon.DesiredSize));

            var ripEllipse = children[1] as Path;
            ripEllipse.Measure(size);
            ripEllipse.Arrange(new Rect(ripEllipse.DesiredSize));

            var arc = children[2] as Path;
            arc.Measure(size);
            arc.Arrange(new Rect(arc.DesiredSize));
            return size;
        }
        protected override void OnRender(DrawingContext drawingContext) {
            ellipse.Draw(drawingContext, new Point(size.Width/2, size.Height/2), size.Width/2);
        }
        protected override void OnMouseEnter(MouseEventArgs e) {
            ellipse.Animate(Colors.Teal);
            pathIconAnim.To = Colors.White;
            pathIconBrush.BeginAnimation(SolidColorBrush.ColorProperty, pathIconAnim);
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            ellipse.Animate(Colors.LightBlue);
            pathIconAnim.To = Colors.Gray;
            pathIconBrush.BeginAnimation(SolidColorBrush.ColorProperty, pathIconAnim);
        }
        protected override void OnMouseUp(MouseButtonEventArgs e) {
            if (!IsRunning) {
                rippleEllipse.Center = e.GetPosition(this);
                rippleEllipse.BeginAnimation(EllipseGeometry.RadiusXProperty, rippleAnim);
                rippleEllipse.BeginAnimation(EllipseGeometry.RadiusYProperty, rippleAnim);
                Command.Execute(CommandParameter);
            }
        }
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;

        #region mess
        public string Icon {
            get { return (string)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }

        public static readonly DependencyProperty IconProperty =
            DependencyProperty.Register("Icon", typeof(string), typeof(RoundButton), new PropertyMetadata(null, onIconChanged));


        public ICommand Command {
            get { return (ICommand)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.Register("Command", typeof(ICommand), typeof(RoundButton), new PropertyMetadata(null, onCommandChanged));


        public object CommandParameter {
            get { return GetValue(CommandParameterProperty); }
            set { SetValue(CommandParameterProperty, value); }
        }

        public static readonly DependencyProperty CommandParameterProperty =
            DependencyProperty.Register("CommandParameter", typeof(object), typeof(RoundButton), new PropertyMetadata(null));


        public bool IsRunning {
            get { return (bool)GetValue(IsRunningProperty); }
            set { SetValue(IsRunningProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsRunning.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsRunningProperty =
            DependencyProperty.Register("IsRunning", typeof(bool), typeof(RoundButton), new PropertyMetadata(false, onIsRunningChanged));

        static void onIsRunningChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as RoundButton;
            if ((bool)e.NewValue) {
                o.arcRotateClock.Controller.Begin();
                o.arc.Visibility = Visibility.Visible;
            }
            else {
                o.arcRotateClock.Controller.Stop();
                o.arc.Visibility = Visibility.Hidden;
            }
        }

        static void onCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as RoundButton;
            if(e.OldValue != null) {
                o.Command.CanExecuteChanged -= o.resetButton; //
            }
            o.Command.CanExecuteChanged += o.resetButton;
        }

        static void onIconChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as RoundButton;
            o.pathIcon.Data = Geometry.Parse(o.Icon);
        }
        #endregion
    }

    public class RoundEllipse
    {
        ColorAnimation anim;
        SolidColorBrush brush;

        public RoundEllipse() {
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            brush = new SolidColorBrush(Colors.LightBlue);
        }
        public void Draw(DrawingContext dc, Point center, double radius) => dc.DrawEllipse(brush, null, center, radius, radius);
        public void Animate(Color to) {
            anim.To = to;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
    }
}
