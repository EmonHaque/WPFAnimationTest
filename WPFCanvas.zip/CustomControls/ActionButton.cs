﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    class ActionButton : FrameworkElement
    {
        Border border;
        SolidColorBrush brush;
        ColorAnimation anim;
        Size size;
        int widthAndHeight;
        public int WidthAndHeight {
            get { return widthAndHeight; }
            set { widthAndHeight = value; size = new Size(value, value); }
        }
        string pathData;
        public string PathData {
            get { return pathData; }
            set { pathData = value; ((Path)border.Child).Data = Geometry.Parse(value); }
        }

        public Action Command { get; set; }

        public ActionButton() {
            brush = new SolidColorBrush(Colors.Black);
            border = new Border() {
                Background = Brushes.Transparent,
                Child = new Path() {
                    Fill = brush,
                    Stretch = Stretch.Uniform
                }
            };
            AddVisualChild(border);
            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
        }

        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
        protected override Size MeasureOverride(Size availableSize) {
            border.Measure(size);
            return size;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(size));
            return size;
        }
        protected override void OnMouseEnter(MouseEventArgs e) {
            anim.To = Colors.Coral;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        protected override void OnMouseUp(MouseButtonEventArgs e) => Command.Invoke();
        protected override void OnMouseLeave(MouseEventArgs e) {
            anim.To = Colors.Black;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
    }
}
