﻿using _3DTools;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;

namespace WPFCanvas.CustomControls
{
    class Plot3D : FrameworkElement
    {
        Viewport3D port;
        PerspectiveCamera camera;
        Model3DGroup models;
        Point3DAnimationUsingKeyFrames positionAnim;
        Vector3DAnimationUsingKeyFrames lookAnim;

        public Plot3D() {
            camera = new PerspectiveCamera() {
                FieldOfView = 80,
                LookDirection = new Vector3D(0, -12, 9),
                Position = new Point3D(0, 12, -9),
                UpDirection = new Vector3D(0, 1, 0)
            };
            models = new Model3DGroup() { Children = { new AmbientLight(Colors.White) } };
            port = new Viewport3D() {
                Camera = camera,
                Children = { new ModelVisual3D() { Content = models } }
            };
            AddVisualChild(port);
            addModels();

            positionAnim = new Point3DAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearPoint3DKeyFrame(new Point3D( 0, 9,-9), TimeSpan.FromSeconds(0)),
                    new LinearPoint3DKeyFrame(new Point3D(-9,-9, 0), TimeSpan.FromSeconds(5)),
                    new LinearPoint3DKeyFrame(new Point3D( 0, 9, 9), TimeSpan.FromSeconds(10)),
                    new LinearPoint3DKeyFrame(new Point3D( 9,-9, 0), TimeSpan.FromSeconds(15)),
                    new LinearPoint3DKeyFrame(new Point3D( 0, 9, -9), TimeSpan.FromSeconds(20)),
                },
                RepeatBehavior = RepeatBehavior.Forever
            };
            lookAnim = new Vector3DAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearVector3DKeyFrame(new Vector3D( 0,-9, 9), TimeSpan.FromSeconds(0)),
                    new LinearVector3DKeyFrame(new Vector3D( 9, 9, 0), TimeSpan.FromSeconds(5)),
                    new LinearVector3DKeyFrame(new Vector3D( 0,-9, -9), TimeSpan.FromSeconds(10)),
                    new LinearVector3DKeyFrame(new Vector3D(-9, 9, 0), TimeSpan.FromSeconds(15)),
                    new LinearVector3DKeyFrame(new Vector3D( 0,-9, 9), TimeSpan.FromSeconds(20)),
                },
                RepeatBehavior = RepeatBehavior.Forever
            };
            Loaded += animate;
        }

        void addAxis() {
            var xAxis = new ScreenSpaceLines3D() { Thickness = 2, Color = Colors.Red };
            var zAxis = new ScreenSpaceLines3D() { Thickness = 2, Color = Colors.Yellow };

            for (int i = -3; i < 4; i++) {
                xAxis.Points.Add(new Point3D(i, 0, -3));
                xAxis.Points.Add(new Point3D(i, 0, 3));

                zAxis.Points.Add(new Point3D(-3, 0, i));
                zAxis.Points.Add(new Point3D(3, 0, i));
            }
            var yAxis = new ScreenSpaceLines3D() { 
                Points = new Point3DCollection() {
                    new Point3D(0, 0, 0),
                    new Point3D(0, 8, 0)
                }, 
                Thickness = 2, 
                Color = Colors.Green 
            };

            port.Children.Add(xAxis);
            port.Children.Add(yAxis);
            port.Children.Add(zAxis);
        }

        void animate(object sender, RoutedEventArgs e) {
            camera.BeginAnimation(PerspectiveCamera.PositionProperty, positionAnim);
            camera.BeginAnimation(PerspectiveCamera.LookDirectionProperty, lookAnim);
        }

        void addModels() {
            //addParabolicSurface();
            //addPlane();
            //addAxis();
            addSphere();
        }

        int currentPhi, currentTheta;
        void addSphere() {
            var yAxis = new ScreenSpaceLines3D() { 
                Color = Colors.Red, 
                Thickness = 3,
                Points = {
                    new Point3D(0, -5, 0),
                    new Point3D(0, 5, 0),
                }
            };
            port.Children.Add(yAxis);

            var mesh = new MeshGeometry3D();
            double radius = 4;
            int dPhi, dTheta;
            dTheta = dPhi = 5;

            for (int phi = 0; phi < 180; phi+=dPhi) {
                currentPhi = phi;
                for (int theta = 0; theta < 360; theta+=dTheta) {
                    currentTheta = theta;
                    var p1 = sphericalPoint(radius, phi, theta);
                    var p2 = sphericalPoint(radius, phi + dPhi, theta);
                    var p3 = sphericalPoint(radius, phi + dPhi, theta + dTheta);
                    var p4 = sphericalPoint(radius, phi, theta + dTheta);
                    //addWires(p1, p2, p3, p4);
                    addTriangleWithTexture(mesh, p1, p2, p3);
                    addTriangleWithTexture(mesh, p3, p4, p1);
                }
            }
            var sphere = new GeometryModel3D() {
                Geometry = mesh,
                Material = new DiffuseMaterial(new ImageBrush() { 
                    ImageSource = new BitmapImage(new Uri("Images/map.jpg", UriKind.Relative))
                })
            };
            models.Children.Add(sphere);
        }

        Point3D sphericalPoint(double radius, int phi, int theta) {
            var thetaRadian = (double)theta / 180 * Math.PI;
            var phiRadian = (double)phi / 180 * Math.PI;
            return new Point3D() {
                X = radius * Math.Sin(phiRadian) * Math.Cos(thetaRadian),
                Y = radius * Math.Cos(phiRadian),
                Z = - radius * Math.Sin(phiRadian) * Math.Sin(thetaRadian)
            };
        }

        void addPlane() {
            var plane = new GeometryModel3D() {
                Geometry = new MeshGeometry3D() {
                    Positions = {
                        new Point3D(-3, 0, 3),
                        new Point3D( 3, 0, 3),
                        new Point3D(-3, 0,-3),
                        new Point3D( 3, 0,-3),
                    },
                    TriangleIndices = { 0, 1, 2, 2, 1, 3 }
                },
                Material = new DiffuseMaterial(Brushes.LightGray)
            };
            models.Children.Add(plane);
        }

        void addParabolicSurface() {
            var mesh = new MeshGeometry3D();
            double dx, dz;
            dx = dz = 0.25;
            for (double x = -2; x < 2; x += dx) {
                for (double z = -2; z < 2; z += dz) {
                    var p1 = new Point3D(x, f(x, z), z);
                    var p2 = new Point3D(x + dx, f(x + dx, z), z);
                    var p3 = new Point3D(x + dx, f(x + dx, z + dz), z + dz);
                    var p4 = new Point3D(x, f(x, z + dz), z + dz);
                    addTriangle(mesh, p1, p2, p3);
                    addTriangle(mesh, p3, p4, p1);
                    addWires(p1, p2, p3, p4);
                }
            }
            var surface = new GeometryModel3D() {
                Geometry = mesh,
                Material = new DiffuseMaterial(Brushes.LightBlue),
                BackMaterial = new DiffuseMaterial(Brushes.SkyBlue)
            };
            models.Children.Add(surface);
        }

        void addWires(Point3D p1, Point3D p2, Point3D p3, Point3D p4) {
            var line = new ScreenSpaceLines3D() { Color = Colors.Black, Thickness = 1 };
            line.Points.Add(p1);
            line.Points.Add(p2);
            line.Points.Add(p2);
            line.Points.Add(p3);
            line.Points.Add(p3);
            line.Points.Add(p4);
            line.Points.Add(p4);
            line.Points.Add(p1);
            port.Children.Add(line);
        }

        void addTriangle(MeshGeometry3D mesh, Point3D point1, Point3D point2, Point3D point3) {
            // Get the points' indices.
            int index1 = addPoint(mesh.Positions, point1);
            int index2 = addPoint(mesh.Positions, point2);
            int index3 = addPoint(mesh.Positions, point3);

            // Create the triangle.
            mesh.TriangleIndices.Add(index1);
            mesh.TriangleIndices.Add(index2);
            mesh.TriangleIndices.Add(index3);
        }

        int addPoint(Point3DCollection points, Point3D point) {
            // See if the point exists.
            for (int i = 0; i < points.Count; i++) {
                if ((point.X == points[i].X) &&
                    (point.Y == points[i].Y) &&
                    (point.Z == points[i].Z))
                    return i;
            }
            // We didn't find the point. Create it.
            points.Add(point);
            return points.Count - 1;
        }

        void addTriangleWithTexture(MeshGeometry3D mesh, Point3D point1, Point3D point2, Point3D point3) {
            // Get the points' indices.
            int index1 = addPointWithTexture(mesh, point1);
            int index2 = addPointWithTexture(mesh, point2);
            int index3 = addPointWithTexture(mesh, point3);

            // Create the triangle.
            mesh.TriangleIndices.Add(index1);
            mesh.TriangleIndices.Add(index2);
            mesh.TriangleIndices.Add(index3);
        }

        int addPointWithTexture(MeshGeometry3D mesh, Point3D point) {
            // See if the point exists.
            for (int i = 0; i < mesh.Positions.Count; i++) {
                if ((point.X == mesh.Positions[i].X) &&
                    (point.Y == mesh.Positions[i].Y) &&
                    (point.Z == mesh.Positions[i].Z))
                    return i;
            }
            // We didn't find the point. Create it.
            mesh.Positions.Add(point);
            mesh.TextureCoordinates.Add(new Point((double)currentTheta / 360, (double)currentPhi / 180));
            return mesh.Positions.Count - 1;
        }

        double f(double x, double z) => x * x + z * z;
        
        protected override Size ArrangeOverride(Size finalSize) {
            port.Width = finalSize.Width;
            port.Height = finalSize.Height;
            port.Measure(finalSize);
            port.Arrange(new Rect(port.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => port;
        protected override int VisualChildrenCount => 1;
    }
}
