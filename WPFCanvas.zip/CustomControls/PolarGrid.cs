﻿using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    class PolarPlot : FrameworkElement
    {
        Canvas plotArea;
        TranslateTransform translate;
        PolarGrid grid;
        Point center;
        TextBox textField;
        ListBox list;
        Grid container;

        public PolarPlot() {
            initiGrid();
            initPlotArea();
            textField = new TextBox();
            list = new ListBox();

            var outline = new Rectangle() {
                StrokeThickness = 1,
                Stroke = Brushes.Black
            };
            var plotContainer = new Grid() {
                ClipToBounds = true,
                Children = { outline, grid, plotArea }
            };

            Grid.SetRow(textField, 1);
            Grid.SetColumnSpan(textField, 2);
            Grid.SetColumn(plotContainer, 1);

            container = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(100)},
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star)}
                },
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto}
                },
                Children = { list, textField, plotContainer }
            };

            AddVisualChild(container);
        }

        void initiGrid() {
            grid = new PolarGrid();
            grid.CenterChanged += onCenterChanged;
        }

        void onCenterChanged(Point center) {
            this.center = center;
            translate.Y = -plotArea.ActualHeight + center.Y;
            translate.X = center.X;
            drawPlot();
        }

        void initPlotArea() {
            translate = new TranslateTransform();
            plotArea = new Canvas() {
                LayoutTransform = new ScaleTransform() { ScaleY = -1 },
                RenderTransform = translate
            };
        }

        void drawPlot() {
            if (plotArea.Children.Count > 0) plotArea.Children.Clear();
            var poly = new Polyline() { Stroke = Brushes.Green, StrokeThickness = 2 };
            var poly2 = new Polyline() { Stroke = Brushes.Red, StrokeThickness = 2 };
            plotArea.Children.Add(poly);
            plotArea.Children.Add(poly2);
            var points = new PointCollection();
            var points2 = new PointCollection();
            var step = 0.05;
            for (double radian = 0; radian < 2 * Math.PI + step; radian+=step) {
                points.Add(new Point() {
                    X = (grid.step/grid.zoom) * (2 + 4*Math.Cos(radian)) * Math.Cos(radian),
                    Y = (grid.step/grid.zoom) * (2 + 4*Math.Cos(radian)) * Math.Sin(radian)
                });
                points2.Add(new Point() {
                    X = (grid.step / grid.zoom) * (Math.Cos(4*radian)) * Math.Cos(radian),
                    Y = (grid.step / grid.zoom) * (Math.Cos(4*radian)) * Math.Sin(radian)
                });
            }
            poly2.Points = points2;
            poly.Points = points;
        }

        protected override Size ArrangeOverride(Size finalSize) {
            container.Width = finalSize.Width;
            container.Height = finalSize.Height;
            container.Measure(finalSize);
            container.Arrange(new Rect(finalSize));
            return finalSize;
        }
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
            translate.Y = -plotArea.ActualHeight + center.Y;
            drawPlot();
        }
        protected override Visual GetVisualChild(int index) => container;
        protected override int VisualChildrenCount => 1;
    }

    class PolarGrid : FrameworkElement
    {
        VisualCollection children;
        Line x, y;
        Pen pen, dashPen;
        Rectangle hitArea;
        Point start, end;
        bool minor;

        public Point Center;
        public double maxRadius, step, zoom;
        public event Action<Point> CenterChanged;

        public PolarGrid() {
            ClipToBounds = true;
            pen = new Pen(Brushes.LightGray, 1);
            dashPen = new Pen() {
                Brush = Brushes.LightGray,
                Thickness = 1,
                DashCap = PenLineCap.Round,
                DashStyle = DashStyles.DashDotDot
            };
            step = 50;
            zoom = 1;
            x = new Line() { Stroke = Brushes.LightBlue, StrokeThickness = 2 };
            y = new Line() { Stroke = Brushes.LightBlue, StrokeThickness = 2 };
            hitArea = new Rectangle() { Fill = Brushes.Transparent };
            children = new VisualCollection(this) { hitArea, x, y };
            Loaded += onLoaded;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            Center.X = ActualWidth / 2;
            Center.Y = ActualHeight / 2;
            InvalidateMeasure();
            InvalidateVisual();
        }
        double getLength() {
            var topLeft = new Point(0, 0);
            var topRight = new Point(ActualWidth, 0);
            var bottomLeft = new Point(0, ActualHeight);
            var bottomRight = new Point(ActualWidth, ActualHeight);

            var topLeftLength = Math.Sqrt(Math.Pow(Center.X - topLeft.X, 2) + Math.Pow(Center.Y - topLeft.Y, 2));
            var topRightLength = Math.Sqrt(Math.Pow(Center.X - topRight.X, 2) + Math.Pow(Center.Y - topRight.Y, 2)); ;
            var bottomLeftLength = Math.Sqrt(Math.Pow(Center.X - bottomLeft.X, 2) + Math.Pow(Center.Y - bottomLeft.Y, 2)); ;
            var bottomRighttLength = Math.Sqrt(Math.Pow(Center.X - bottomRight.X, 2) + Math.Pow(Center.Y - bottomRight.Y, 2)); ;

            return new double[] { topLeftLength, topRightLength, bottomLeftLength, bottomRighttLength}.Max();
        }
        FormattedText formatText(string text) {
            return new FormattedText(
                    text,
                    Thread.CurrentThread.CurrentCulture,
                    FlowDirection.LeftToRight,
                    new Typeface(SystemFonts.MessageFontFamily, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal),
                    11,
                    Brushes.Black,
                    VisualTreeHelper.GetDpi(this).PixelsPerDip
                );
        }
        protected override Size MeasureOverride(Size availableSize) {
            x.Y1 = x.Y2 = Center.Y;
            x.X2 = availableSize.Width;
            y.X1 = y.X2 = Center.X;
            y.Y2 = availableSize.Height;
            x.Measure(availableSize);
            y.Measure(availableSize);

            hitArea.Width = availableSize.Width;
            hitArea.Height = availableSize.Height;
            hitArea.Measure(availableSize);
            return availableSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            x.Arrange(new Rect(x.DesiredSize));
            y.Arrange(new Rect(y.DesiredSize));
            hitArea.Arrange(new Rect(hitArea.DesiredSize));
            return finalSize;
        }
        protected override void OnRender(DrawingContext dc) {
            maxRadius = 0;
            var distance = getLength();
            var radius = step;
            while (radius < distance) {
                dc.DrawEllipse(null, pen, Center, radius, radius);
                dc.DrawText(formatText((maxRadius + zoom).ToString("N1")), new Point(Center.X + radius, Center.Y));
                dc.DrawText(formatText((maxRadius + zoom).ToString("N1")), new Point(Center.X - radius, Center.Y));
                dc.DrawText(formatText((maxRadius + zoom).ToString("N1")), new Point(Center.X, Center.Y + radius));
                dc.DrawText(formatText((maxRadius + zoom).ToString("N1")), new Point(Center.X, Center.Y - radius));
                if (minor) dc.DrawEllipse(null, dashPen, Center, radius + step/2, radius+step/2);

                radius += step;
                maxRadius += zoom;
            }
            for (double radian = 0; radian < 2 * Math.PI; radian += Math.PI / 6) {
                var point = new Point() {
                    X = radius * Math.Cos(radian) + Center.X,
                    Y = radius * Math.Sin(radian) + Center.Y
                };
                dc.DrawLine(pen, Center, point);
            }
            CenterChanged?.Invoke(Center);
        }
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) => start = e.GetPosition(this);
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            end = e.GetPosition(this);
            Center.X += end.X - start.X;
            Center.Y += end.Y - start.Y;
            InvalidateMeasure();
            InvalidateVisual();
        }
        protected override void OnMouseWheel(MouseWheelEventArgs e) {
            minor = !minor;
            if (!minor) {
                if (e.Delta > 0) {
                    zoom += 0.1;
                }
                else {
                    if (Math.Round(zoom, 2) > 0.1)
                        zoom -= 0.1;
                }
            }
            InvalidateMeasure();
            InvalidateVisual();
        }
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;
    }
}
