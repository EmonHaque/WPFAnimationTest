﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WPFCanvas.UIs;

namespace WPFCanvas.CustomControls
{
    public class PieChart : Panel
    {
        #region mess
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ItemSource.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(PieChart), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as PieChart;
            int colorIndex = 0;
            if (e.OldValue != null) o.Children.Clear();
            if (o.ItemSource != null) {
                foreach (int item in o.ItemSource) {
                    o.total += item;
                    var slice = new Slice(o.colors[colorIndex++], item);
                    o.Children.Add(slice);
                    slice.MouseEnter += o.showPopup;
                    slice.MouseLeave += o.hidePopup;
                }
                var path = new Path() {
                    Fill = Brushes.White,
                    Data = new EllipseGeometry()
                };
                o.Children.Add(path);
            }
        }
        #endregion
        // Any auto property of a "Control" could've been a DependencyProperty and had an associalted callback!

        List<SolidColorBrush> colors;
        Popup pop;
        TextBlock value, percentage;
        Path ellipse;
        int total;
        DoubleAnimation ellipseAnim;
        BooleanAnimationUsingKeyFrames popOpenAnim, popCloseAnim;

        public PieChart() {
            colors = new List<SolidColorBrush>() {
                Brushes.LightBlue,
                Brushes.LightGray,
                Brushes.Brown,
                Brushes.Beige,
                Brushes.Bisque
            };

            value = new TextBlock() {
                FontSize = 32,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                HorizontalAlignment = HorizontalAlignment.Center,
                TextAlignment = TextAlignment.Center
            };

            percentage = new TextBlock() {
                Foreground = Brushes.Blue,
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                TextAlignment = TextAlignment.Center
            };

            pop = new Popup() {
                AllowsTransparency = true,
                PlacementTarget = this,
                Placement = PlacementMode.Center,
                Child = new StackPanel() {
                    Children = {
                        value,
                        new Separator(){Background = Brushes.LightBlue},
                        percentage
                    }
                }
            };

            ellipseAnim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(1),
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };

            popOpenAnim = new BooleanAnimationUsingKeyFrames() {
                KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1.5)),
                }
            };
            popCloseAnim = new BooleanAnimationUsingKeyFrames() {
                KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(1)),
                }
            };
        }

        protected override Size ArrangeOverride(Size finalSize) {
            if(ItemSource != null) {
                var data = ItemSource.Cast<int>().ToArray();
                var total = data.Sum();
                var currentIndex = 0;

                var cx = finalSize.Width / 2;
                var cy = finalSize.Height / 2;

                double radius, startAngle, sweepAngle, endAngle;
                radius = startAngle = sweepAngle = endAngle = 0;

                if (cx > cy) radius = cy;
                else radius = cx;

                foreach (Slice item in Children.OfType<Slice>()) {
                    var value = data[currentIndex++];
                    startAngle += sweepAngle;
                    sweepAngle = 2 * Math.PI * value / total;
                    endAngle = startAngle + sweepAngle;
                    bool isLarge = (double)value / total > 0.5;

                    item.SetParameters(cx, cy, radius, startAngle, sweepAngle, isLarge);
                    item.Arrange(new Rect(item.DesiredSize));
                }

                ellipse = Children.OfType<Path>().First();
                var geo = ellipse.Data as EllipseGeometry;
                geo.RadiusX = geo.RadiusY = radius - 100;
                geo.Center = new Point(cx, cy);
                ellipse.Measure(finalSize);
                ellipse.Arrange(new Rect(ellipse.DesiredSize));
                ellipse.RenderTransform = new ScaleTransform(0, 0);
            }
            return finalSize;
        }

        void animateEllipse(double scale) {
            double x, cx, y, cy;
            x = y = 0;
            cx = ActualWidth / 2;
            cy = ActualHeight / 2;

            
            var transform = ellipse.RenderTransform as ScaleTransform;
            if(scale == 1) {
                x = y = 0;
                pop.BeginAnimation(Popup.IsOpenProperty, popOpenAnim);
            }
            else {
                x = transform.ScaleX;
                y = transform.ScaleY;
                pop.BeginAnimation(Popup.IsOpenProperty, popCloseAnim);
            }
            ellipse.RenderTransform = new ScaleTransform(x, y, cx, cy);
            ellipseAnim.To = scale;
            ellipse.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, ellipseAnim);
            ellipse.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, ellipseAnim);
        }

        void hidePopup(object sender, System.Windows.Input.MouseEventArgs e) {
            animateEllipse(0);
        }

        void showPopup(object sender, System.Windows.Input.MouseEventArgs e) {
            double val = (sender as Slice).value;
            value.Text = val.ToString("N2");
            percentage.Text = (val / total * 100).ToString("N2") + " %";
            animateEllipse(1);
        }
    }
}
