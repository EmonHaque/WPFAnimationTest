﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    class Trig : FrameworkElement
    {
        VisualCollection kids;
        EllipseGeometry circle, ball, joint, tanJoint;
        ArcSegment angle;
        Path circlePath, ballPath, anglePath;
        Line hypo, invHypo, sine, cosine, tangent, xAxis, yAxis;
        double radius;
        Canvas canvas;
        Grid hitArea;

        public Trig() {
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
            hitArea = new Grid() { Background = Brushes.Transparent };
            circle = new EllipseGeometry();
            ball = new EllipseGeometry() { Center = new Point(0, 0), RadiusX = 5, RadiusY = 5 };
            angle = new ArcSegment() {
                SweepDirection = SweepDirection.Clockwise,
                Size = new Size(40, 40),
                IsLargeArc = true,
                IsStroked = true,
            };
            joint = new EllipseGeometry() { RadiusX = 3, RadiusY = 3 };
            tanJoint = new EllipseGeometry() { RadiusX = 3, RadiusY = 3 };

            circlePath = new Path() {
                Stroke = Brushes.LightBlue,
                StrokeThickness = 3,
                Data = circle
            };
            ballPath = new Path() {
                Fill = Brushes.LightCoral,
                Data = ball,
                RenderTransform = new MatrixTransform()
            };
            anglePath = new Path() {
                Fill = new SolidColorBrush(Color.FromArgb(50, 0, 0, 50)),
                StrokeThickness = 1,
                Stroke = Brushes.Black,
                Data = new PathGeometry() {
                    Figures = {
                        new PathFigure() {
                            Segments = {
                                new LineSegment(){IsStroked = false},
                                angle
                            }
                        }
                    }
                }
            };
            var jointPath = new Path() {
                Fill = Brushes.Coral,
                Data = joint
            };
            var tanJointPath = new Path() {
                Fill = Brushes.Coral,
                Data = tanJoint
            };

            hypo = new Line() {
                Stroke = Brushes.Black,
                StrokeThickness = 0.5,
                StrokeDashCap = PenLineCap.Round,
                StrokeDashArray = new DoubleCollection(new double[] { 5, 5 })
            };
            invHypo = new Line() {
                Stroke = Brushes.Gray,
                StrokeThickness = 0.5,
                StrokeDashCap = PenLineCap.Round,
                StrokeDashArray = new DoubleCollection(new double[] { 5, 5 })
            };
            sine = new Line() { Stroke = Brushes.Blue, StrokeThickness = 2 };
            cosine = new Line() { Stroke = Brushes.Red, StrokeThickness = 2 };
            tangent = new Line() { Stroke = Brushes.Green, StrokeThickness = 2 };
            xAxis = new Line() { Stroke = Brushes.Black, StrokeThickness = 1, X1 = 0, Y1 = 0, Y2 = 0 };
            yAxis = new Line() { Stroke = Brushes.Black, StrokeThickness = 1, X1 = 0, X2 = 0, Y1 = 0 };
            canvas = new Canvas() {
                Children = { xAxis, yAxis, circlePath, anglePath, sine, cosine, tangent, hypo, invHypo, jointPath, tanJointPath, ballPath },
                RenderTransform = new TransformGroup() {
                    Children = {
                        new ScaleTransform(),
                        new TranslateTransform()
                    }
                }
            };
            kids = new VisualCollection(this) { canvas, hitArea };
            ballPath.RenderTransform.Changed += onTransformed;
            canvas.Loaded += animate;
        }

        void onTransformed(object sender, EventArgs e) {
            var mat = ((MatrixTransform)sender).Matrix;
            cosine.X2 = sine.X1 = sine.X2 = mat.OffsetX;
            sine.Y2 = mat.OffsetY;
            

            var y2 = (mat.OffsetY / mat.OffsetX) * radius;
            var tanY = double.IsNaN(y2) ? 0 : y2;
            tanJoint.Center = new Point(radius, tanY);
            joint.Center = new Point(mat.OffsetX, 0);

            if(mat.OffsetX < 0) {
                invHypo.Visibility = Visibility.Visible;
                invHypo.X2 = radius;
                invHypo.Y2 = tangent.Y2 = tanY;

                hypo.X2 = mat.OffsetX;
                hypo.Y2 = mat.OffsetY;
            }
            else {
                invHypo.Visibility = Visibility.Hidden;
                hypo.X2 = radius;
                hypo.Y2 = tangent.Y2 = tanY;
            }
        }

        void animate(object sender, RoutedEventArgs e) {
            var circleGeo = PathGeometry.CreateFromGeometry(circle);
            var angleGeo = new PathGeometry() {
                Figures = {
                    new PathFigure() {
                        StartPoint = new Point(40, 0),
                        Segments = { ((PathGeometry)anglePath.Data).Figures[0].Segments[1].Clone() }
                    }
                }
            };
            circleGeo.Freeze();
            angleGeo.Freeze();

            var ballAnim = new MatrixAnimationUsingPath() {
                Duration = TimeSpan.FromSeconds(10),
                RepeatBehavior = RepeatBehavior.Forever,
                PathGeometry = circleGeo
            };
            var angleAnim = new PointAnimationUsingPath() {
                PathGeometry = angleGeo,
                Duration = TimeSpan.FromSeconds(10),
                RepeatBehavior = RepeatBehavior.Forever
            };
            var angleIsLargeAnim = new BooleanAnimationUsingKeyFrames() {
                RepeatBehavior = RepeatBehavior.Forever,
                KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(5)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(10)),
                }
            };
            var innerArcSizeAnim = new SizeAnimation() {
                To = new Size(radius, radius),
                RepeatBehavior = RepeatBehavior.Forever,
                Duration = TimeSpan.FromSeconds(10)
            };
            var startPointAnim = new PointAnimation() {
                To = new Point(radius,0),
                RepeatBehavior = RepeatBehavior.Forever,
                Duration = TimeSpan.FromSeconds(10)
            };
            var endPointAnim = new PointAnimation() {
                To = new Point(radius,  - 0.01),
                RepeatBehavior = RepeatBehavior.Forever,
                Duration = TimeSpan.FromSeconds(10)
            };
            angle.BeginAnimation(ArcSegment.IsLargeArcProperty, angleIsLargeAnim);
            angle.BeginAnimation(ArcSegment.PointProperty, angleAnim);
            ballPath.RenderTransform.BeginAnimation(MatrixTransform.MatrixProperty, ballAnim);
        }

        protected override Size MeasureOverride(Size availableSize) {

            canvas.Width = hitArea.Width = availableSize.Width;
            canvas.Height = hitArea.Height = availableSize.Height;
            radius = Math.Min((availableSize.Width) / 2, (availableSize.Height) / 2);

            circle.RadiusX = circle.RadiusY = tangent.X1 = tangent.X2 = radius;
            ((LineSegment)((PathGeometry)anglePath.Data).Figures[0].Segments[0]).Point = new Point(40, 0);
            angle.Point = new Point(40, -0.01);
            tangent.Y1 = 0;

            foreach (UIElement kid in kids)
                kid.Measure(availableSize);
            foreach (UIElement kid in canvas.Children)
                kid.Measure(availableSize);
            return availableSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            foreach (UIElement kid in kids) 
                kid.Arrange(new Rect(kid.DesiredSize));
            foreach (UIElement kid in canvas.Children)
                kid.Arrange(new Rect(kid.DesiredSize));
            return finalSize;
        }
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
            var translate = new TranslateTransform() {
                X = sizeInfo.NewSize.Width/2,
                Y = -sizeInfo.NewSize.Height/2
            };
            RenderTransform = translate;

            hitArea.RenderTransform = new TranslateTransform() {
                X = -translate.X,
                Y = translate.Y
            };

            xAxis.X2 = translate.X;
            yAxis.Y2 = -translate.Y;
            angle.BeginAnimation(ArcSegment.IsLargeArcProperty, null);
            angle.BeginAnimation(ArcSegment.PointProperty, null);
            ballPath.RenderTransform.BeginAnimation(MatrixTransform.MatrixProperty, null);
            animate(null, null);
        }

        protected override void OnMouseWheel(MouseWheelEventArgs e) {
            var zoomPoint = e.GetPosition(this);
            var scale = (ScaleTransform)((TransformGroup)canvas.RenderTransform).Children[0];
            scale.CenterX = zoomPoint.X;
            scale.CenterY = zoomPoint.Y;

            if(e.Delta > 0) {
                scale.ScaleX *= 1.1;
                scale.ScaleY *= 1.1;
            }
            else {
                scale.ScaleX *= 0.9;
                scale.ScaleY *= 0.9;
            }
        }
        protected override Visual GetVisualChild(int index) => kids[index];
        protected override int VisualChildrenCount => kids.Count;
    }
}
