﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WPFCanvas.UIs;

namespace WPFCanvas.CustomControls
{
    public class LineChart : Panel
    {
        #region mess
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }

        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(LineChart), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as LineChart;
            if (e.OldValue != null) o.Children.Clear();
            if(o.ItemSource != null) {
                var values = o.ItemSource.Cast<int>().ToList();
                var path = new LineStream(values);
                o.Children.Add(path);
                SetZIndex(path, 1);
                o.Children.Add(new Pointer());

                o.numPoints = values.Count;
                foreach (var value in values) {
                    o.addCircle(value);
                    o.addLabel(value);
                    if (value > o.maxValue) o.maxValue = value;
                    if (value < o.minValue) o.minValue = value;
                }
                var min = o.minValue < 0 ? o.minValue - 10 : 0;
                var step = min < 0 ? (o.maxValue + 10 + Math.Abs(min)) / 9 : (o.maxValue + 10) / 9;
                double current = min;
                for (int i = 0; i < 10; i++) {
                    o.addLine();
                    o.addTick(current);
                    current += step;
                }
            }
        }
        #endregion

        int numPoints;
        double minValue, maxValue, labelWidth;
        Pointer pointer;
        Popup pop;
        TextBlock block;

        public LineChart() {
            Background = Brushes.Transparent;
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
            block = new TextBlock() { FontSize = 24, Background = Brushes.LightBlue };
            block = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            pop = new Popup() {
                AllowsTransparency = true,
                Child = new Border() {
                    Child = block,
                    CornerRadius = new CornerRadius(20),
                    Padding = new Thickness(5),
                    BorderBrush = Brushes.Black,
                    Background = Brushes.LightBlue,
                    BorderThickness = new Thickness(1)
                },
                Placement = PlacementMode.MousePoint
            };
        }

        void addCircle(int value) {
            var circle = new Circle(value);
            Children.Add(circle);
            circle.OnPointerOver += showPopup;
            circle.OnPointerAway += hidePopup;
        }

        void addLabel(int value) {
            var label = new TextBlock() {
                Text = value.ToString(),
                IsHitTestVisible = false,
                TextAlignment = TextAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
                }
            };
            Children.Add(label);
        }

        void addLine() {
            var line = new Line() {
                StrokeThickness = 1,
                Stroke = Brushes.LightBlue,
                IsHitTestVisible = false
            };
            SetZIndex(line, 0);
            Children.Add(line);
            line.Loaded += animateLines;
        }

        void animateLines(object sender, RoutedEventArgs e) {
            var duration = TimeSpan.FromSeconds(5);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            var translateAnim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(2),
                To = 0,
                Duration = duration,
                EasingFunction = ease
            };
            var scaleAnim = new DoubleAnimation() {
                From = 0,
                Duration = duration,
                EasingFunction = ease
            };
            var line = sender as Line;
            var translate = new TranslateTransform(0, ActualHeight/2 - line.Y1);
            var scale = new ScaleTransform(1, 1) { CenterX = ActualWidth / 2 };
            line.RenderTransform = new TransformGroup() { Children = { translate, scale } };
            translate.BeginAnimation(TranslateTransform.YProperty, translateAnim);
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnim);
        }

        void addTick(double current) {
            var tick = new Label() {
                Content = current.ToString("N2"),
                HorizontalAlignment = HorizontalAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                },
                IsHitTestVisible = false
            };
            Children.Add(tick);
        }

        protected override Size ArrangeOverride(Size finalSize) {
            if(ItemSource != null) {
                var minStr = (minValue - 10).ToString();
                var maxStr = (maxValue + 10).ToString();

                var testTick = new Label() { Content = minStr.Length > maxStr.Length ? minStr : maxStr };
                var testLabel = new TextBlock(){ 
                    Text = minStr.Length > maxStr.Length ? minStr : maxStr,
                    RenderTransform = new RotateTransform(90)
                };
                testLabel.Measure(finalSize);
                testTick.Measure(finalSize);
                var labelWidth = this.labelWidth = Math.Ceiling(testLabel.DesiredSize.Width);
                var tickWidth = Math.Ceiling(testTick.DesiredSize.Width);

                var horizontalSpace = (finalSize.Width - tickWidth) / numPoints;
                double verticalSpace = finalSize.Height / 10;
                double lineY = 0;
                double tickY = 0;
                double labelX = horizontalSpace;
                double circleX = horizontalSpace;

                var lower = minValue < 0 ? Math.Abs(minValue - 10) : 0;
                var upper = maxValue + 10;
                var availableHeight = finalSize.Height / 10 * 9;
                var posHeight = availableHeight / (lower + upper) * upper;
                var negHeight = availableHeight - posHeight;

                foreach (var item in Children) {
                    if(item is LineStream) {
                        var line = item as LineStream;
                        line.SetParameters(finalSize.Width, finalSize.Height, lower, upper, tickWidth, labelWidth);
                        line.Arrange(new Rect(line.DesiredSize));
                    }
                    if (item is Pointer) {
                        var pointer = item as Pointer;
                        pointer.SetParameters(0, finalSize.Height, labelWidth);
                        pointer.Arrange(new Rect(pointer.DesiredSize));
                        pointer.Visibility = Visibility.Hidden;
                        this.pointer = pointer;
                    }
                    if (item is Circle) {
                        var circle = item as Circle;
                        var y = circle.value < 0 ? negHeight - Math.Abs(circle.value) / lower * negHeight : circle.value / upper * posHeight + negHeight;
                        circle.SetCenter(new Point(circleX + tickWidth, y + labelWidth));
                        circle.Arrange(new Rect(circle.DesiredSize));
                        circleX += horizontalSpace;
                    }
                    if (item is Line) {
                        var line = item as Line;
                        line.X2 = finalSize.Width;
                        line.Y1 = line.Y2 = labelWidth + lineY;
                        line.Measure(finalSize);
                        line.Arrange(new Rect(line.DesiredSize));
                        lineY += verticalSpace;
                    }
                    if (item is TextBlock) {
                        var label = item as TextBlock;
                        label.Width = testLabel.DesiredSize.Width;
                        label.Height = testLabel.DesiredSize.Height;
                        label.Measure(finalSize);
                        label.Arrange(new Rect(new Point(labelX + tickWidth - labelWidth/2, 0), label.DesiredSize));
                        labelX += horizontalSpace;
                    }
                    if (item is Label) {
                        var tick = item as Label;
                        tick.Measure(finalSize);
                        tick.Arrange(new Rect(new Point(0, tickY + tick.DesiredSize.Height + labelWidth), tick.DesiredSize));
                        tickY += verticalSpace;
                    }
                }
            }
            return finalSize;
        }

        protected override void OnMouseEnter(MouseEventArgs e) => pointer.Visibility = Visibility.Visible;
        protected override void OnMouseMove(MouseEventArgs e) => pointer.SetParameters(e.GetPosition(this).X, ActualHeight, labelWidth);
        protected override void OnMouseLeave(MouseEventArgs e) => pointer.Visibility = Visibility.Hidden;
        void hidePopup() => pop.IsOpen = false;

        void showPopup(Circle c) {
            //pop.PlacementTarget = c; // ??
            block.Text = c.value.ToString();
            pop.IsOpen = true;
        }
    }
}
