﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WPFCanvas.Model;

namespace WPFCanvas.CustomControls
{
    class SuggestionBox : FrameworkElement
    {
        Border border, selectionBorder;
        StackPanel selectionPanel;

        TextBox text;
        Grid container;
        Path arrow, close;
        ListBox list;
        Popup pop;
        ICollectionView view;
        DoubleAnimation arrowAnim;
        DataTemplate itemTemplate;

        public DataTemplate ItemTemplate {
            get { return itemTemplate; }
            set { 
                itemTemplate = value;
                list.ItemTemplate = value;
            }
        }

        public SuggestionBox() {

            addRootVisual();
            list = new ListBox() {
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                IsSynchronizedWithCurrentItem = true
            };
            pop = new Popup() {
                AllowsTransparency = true,
                StaysOpen = false,
                MaxHeight = 200,
                Placement = PlacementMode.Bottom,
                PlacementTarget = border,
                Child = list
            };

            arrowAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            addSelectionUI();

            text.TextChanged += filterList;
            Loaded += transformArrow;
            pop.Opened += animateArrow;
            pop.Closed += animateArrow;
            text.KeyUp += focusList;
            list.KeyUp += select;
        }

        void select(object sender, KeyEventArgs e) {
            if(e.Key == Key.Enter) {
                var item = list.SelectedItem as TestItem;
                (selectionPanel.Children[0] as TextBlock).Text = item.Text;
                container.Children.RemoveAt(0);
                container.Children.Insert(0, selectionBorder);
                pop.IsOpen = false;
                SelectedValue = item.Index;
            }
        }

        void focusList(object sender, KeyEventArgs e) {
            if(e.Key == Key.Down) {
                if (pop.IsOpen)
                    (list.ItemContainerGenerator.ContainerFromItem(list.SelectedItem) as ListBoxItem).Focus();
            }
        }

        void addSelectionUI() {
            close = new Path() {
                Fill = Brushes.Black,
                Data = Geometry.Parse("M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z"),
                Stretch = Stretch.Uniform
            };
            var closeBorder = new Border() {
                Margin = new Thickness(10,0,0,0),
                Background = Brushes.Transparent,
                Child = close
            };
            selectionPanel = new StackPanel() {
                Orientation = Orientation.Horizontal,
                Children = { new TextBlock(), closeBorder }
            };
            selectionBorder = new Border() {
                Background = Brushes.LightGray,
                HorizontalAlignment = HorizontalAlignment.Left,
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(5),
                Child = selectionPanel
            };
            closeBorder.MouseUp += clearSelection;
        }

        void clearSelection(object sender, MouseButtonEventArgs e) {
            container.Children.RemoveAt(0);
            text.Text = string.Empty;
            container.Children.Insert(0, text);
            SelectedValue = null;
        }

        void animateArrow(object sender, EventArgs e) {
            arrowAnim.To = pop.IsOpen ? 0 : 180;
            arrow.RenderTransform.BeginAnimation(RotateTransform.AngleProperty, arrowAnim);
        }

        void transformArrow(object sender, RoutedEventArgs e) {
            arrow.RenderTransform = new RotateTransform(180, arrow.ActualWidth / 2, arrow.ActualHeight / 2);
        }

        void addRootVisual() {
            text = new TextBox() {
                Padding = new Thickness(0, 5, 0, 5),
                BorderThickness = new Thickness(0, 0, 1, 0)
            };
            arrow = new Path() {
                Fill = Brushes.Black,
                Data = Geometry.Parse("M11,6V14L7.5,10.5L6.08,11.92L12,17.84L17.92,11.92L16.5,10.5L13,14V6H11M12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22Z"),
                Width = 32,
                Height = Width,
                Stretch = Stretch.Uniform,
                VerticalAlignment = VerticalAlignment.Center
            };
            var borderArrow = new Border {
                Background = Brushes.Transparent,
                Child = arrow
            };
            Grid.SetColumn(borderArrow, 1);
            container = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { text, borderArrow }
            };
            border = new Border() {
                Padding = new Thickness(5),
                BorderBrush = Brushes.LightBlue,
                BorderThickness = new Thickness(1),
                Child = container
            };
            AddVisualChild(border);
            borderArrow.MouseUp += togglePopupVisibility;
        }

        void togglePopupVisibility(object sender, MouseButtonEventArgs e) => pop.IsOpen = !pop.IsOpen;

        void filterList(object sender, TextChangedEventArgs e) {
            view.Refresh();
            pop.IsOpen = true;
        }

        bool filter(object o) => (o as TestItem).Text.Contains(text.Text);

        protected override Size MeasureOverride(Size availableSize) {
            border.Width = pop.Width = availableSize.Width;
            border.Measure(availableSize);
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(border.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;

        #region mess
        public IEnumerable SuggestionSource {
            get { return (IEnumerable)GetValue(SuggestionSourceProperty); }
            set { SetValue(SuggestionSourceProperty, value); }
        }

        public int? SelectedValue {
            get { return (int?)GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        public static readonly DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue", typeof(int?), typeof(SuggestionBox), new PropertyMetadata(null));

        public static readonly DependencyProperty SuggestionSourceProperty =
            DependencyProperty.Register("SuggestionSource", typeof(IEnumerable), typeof(SuggestionBox), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as SuggestionBox;
            o.view = CollectionViewSource.GetDefaultView(o.SuggestionSource);
            o.view.Filter = o.filter;
            o.list.ItemsSource = o.view;
        }
        #endregion
    }
}
