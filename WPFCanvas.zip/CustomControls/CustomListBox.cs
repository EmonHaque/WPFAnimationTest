﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using WPFCanvas.Model;

namespace WPFCanvas.CustomControls
{
    class CustomListBox : ListBox
    {
        TestItem currentvalue;
        List<char> charArray;
        ObservableCollection<TestItem> internalSource;

        public CustomListBox() {
            SelectionMode = SelectionMode.Extended;
            charArray = new List<char>(10);
            internalSource = new ObservableCollection<TestItem>();
            BindingOperations.EnableCollectionSynchronization(internalSource, internalSource);
            base.ItemsSource = internalSource;
            AddHandler(ScrollViewer.ScrollChangedEvent, new ScrollChangedEventHandler(onScroll));
        }

        void onScroll(object sender, ScrollChangedEventArgs e) {
            charArray.Clear();
            char character;

            for (double i = e.VerticalOffset; i < e.VerticalOffset + e.ViewportHeight; i++) {
                var item = (Item)ItemContainerGenerator.ContainerFromIndex((int)i);
                character = item.value.Text.First();
                var layer = AdornerLayer.GetAdornerLayer(item);
                Adorner[] adorner;
                if ((adorner = layer.GetAdorners(item)) != null) layer.Remove(adorner[0]);

                if(charArray.Count == 0) {
                    layer.Add(new ItemAdorner(item));
                    charArray.Add(character);
                }
                else {
                    if(character != charArray.Last()) {
                        layer.Add(new ItemAdorner(item));
                        charArray.Add(character);
                    }
                }
            }
        }

        protected override DependencyObject GetContainerForItemOverride() => new Item(currentvalue);
        protected override bool IsItemItsOwnContainerOverride(object item) {
            currentvalue = (TestItem)item;
            return false;
        }

        void CollectionChanged(object sender, NotifyCollectionChangedEventArgs e) {
            switch (e.Action) {
                case NotifyCollectionChangedAction.Add:
                    internalSource.Insert(0, (TestItem)e.NewItems[0]);
                    break;
                case NotifyCollectionChangedAction.Remove:
                    var item = (Item)ItemContainerGenerator.ContainerFromItem(e.OldItems[0]);
                    item.IsRemoving = true;
                    item.OnRemoved += () => internalSource.Remove((TestItem)e.OldItems[0]);
                    break;
                case NotifyCollectionChangedAction.Replace:
                    break;
                case NotifyCollectionChangedAction.Move:
                    break;
                case NotifyCollectionChangedAction.Reset:
                    break;
                default:
                    break;
            }
        }

        #region mess
        public new IEnumerable ItemsSource {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        public static new readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(CustomListBox), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as CustomListBox;
            if(e.OldValue != null) {
                (e.OldValue as INotifyCollectionChanged).CollectionChanged -= o.CollectionChanged;
                o.Items.Clear();
            }
            if(e.NewValue != null) {
                foreach (TestItem item in (ICollection)e.NewValue)
                    o.internalSource.Add(item);
                (e.NewValue as INotifyCollectionChanged).CollectionChanged += o.CollectionChanged;
            }
        }
        #endregion
    }

    class Item : ListBoxItem
    {
        TextBlock textBlock;
        SolidColorBrush brush;
        ColorAnimation anim;
        public TestItem value;
        public event Action OnRemoved;

        bool isRemoving; 
        public bool IsRemoving {
            get { return isRemoving; }
            set { isRemoving = value; removeAnim(); }
        }

        public Item(TestItem value) {
            this.value = value;
            brush = new SolidColorBrush(Colors.LightBlue);
            textBlock = new TextBlock() {
                Padding = new Thickness(0, 5, 0, 5),
                Background = brush,
                TextAlignment = TextAlignment.Center,
                Text = value.Text
            };
            AddVisualChild(textBlock);

            anim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            Selected += (s, e) => animate();
            Unselected += (s, e) => animate();
            Loaded += (s, e) => addAnim();
        }

        void animate() {
            if (IsSelected) {
                anim.To = Colors.LightSeaGreen;
                textBlock.Foreground = Brushes.White;
            }
            else {
                anim.To = Colors.LightBlue;
                textBlock.Foreground = Brushes.Black;
            }
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
        void addAnim() {
            RenderTransform = new ScaleTransform(0, 1);
            var anim = new DoubleAnimation() {
                To = 1,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        }
        void removeAnim() {
            var anim = new DoubleAnimation() {
                To = 0,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            BeginAnimation(OpacityProperty, anim);
            anim.Completed += (s,e) => OnRemoved();
            RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        }
        protected override void OnMouseEnter(MouseEventArgs e) {
            if (!IsSelected) {
                anim.To = Colors.LightGray;
                brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
            }
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            if (!IsSelected) {
                anim.To = Colors.LightBlue;
                brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
            }
        }
        protected override Visual GetVisualChild(int index) => textBlock;
        protected override int VisualChildrenCount => 1;
    }

    class ItemAdorner : Adorner
    {
        Border border;
        TextBlock text;

        public ItemAdorner(UIElement element) :base(element) {
            text = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Text = ((Item)element).value.Text.Substring(0, 1),
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White
            };
            border = new Border() {
                Background = Brushes.Black,
                CornerRadius = new CornerRadius(20),
                Child = text
            };
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Width = 30;
            border.Height = finalSize.Height;
            border.Measure(finalSize);
            border.Arrange(new Rect(new Point(0, 0), border.DesiredSize));
            return finalSize;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
    }
}
