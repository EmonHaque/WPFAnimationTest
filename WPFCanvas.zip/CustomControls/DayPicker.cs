﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    class DayPicker : FrameworkElement
    {
        Grid dayContainer, dayNameContainer, headerContainer, grid;
        StackPanel panel;
        TextBlock header, text;
        Path leftIcon, rightIcon, icon;
        Border leftBorder, rightBorder, dayNameBorder, iconBorder, border;
        DateTime currentDate;
        State currentState;
        Popup pop;

        string leftArrow = "M2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12M18,11H10L13.5,7.5L12.08,6.08L6.16,12L12.08,17.92L13.5,16.5L10,13H18V11Z";
        string rightArrow = "M22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12M6,13H14L10.5,16.5L11.92,17.92L17.84,12L11.92,6.08L10.5,7.5L14,11H6V13Z";
        string calendarIcon = "M15.5,12C18,12 20,14 20,16.5C20,17.38 19.75,18.21 19.31,18.9L22.39,22L21,23.39L17.88,20.32C17.19,20.75 16.37,21 15.5,21C13,21 11,19 11,16.5C11,14 13,12 15.5,12M15.5,14A2.5,2.5 0 0,0 13,16.5A2.5,2.5 0 0,0 15.5,19A2.5,2.5 0 0,0 18,16.5A2.5,2.5 0 0,0 15.5,14M19,8H5V19H9.5C9.81,19.75 10.26,20.42 10.81,21H5C3.89,21 3,20.1 3,19V5C3,3.89 3.89,3 5,3H6V1H8V3H16V1H18V3H19A2,2 0 0,1 21,5V13.03C20.5,12.22 19.8,11.54 19,11V8Z";

        public DayPicker() {
            icon = new Path() {
                Fill = Brushes.Black,
                Data = Geometry.Parse(calendarIcon),
                Stretch = Stretch.Uniform,
                Width = 32,
                Height = Width
            };
            iconBorder = new Border() {
                Background = Brushes.Transparent,
                BorderThickness = new Thickness(1, 0, 0, 0),
                BorderBrush = Brushes.LightBlue,
                Child = icon
            };
            Grid.SetColumn(iconBorder, 1);
            text = new TextBlock() {
                Margin = new Thickness(10, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
                Children = {text, iconBorder}
            };
            border = new Border() {
                BorderThickness = new Thickness(1),
                Padding = new Thickness(0, 5, 0, 5),
                BorderBrush = Brushes.LightBlue,
                Child = grid
            };

            AddVisualChild(border);

            string[] days = { "Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri" };
            dayContainer = new Grid();
            dayNameContainer = new Grid();

            for (int i = 0; i < 7; i++) {
                dayNameContainer.ColumnDefinitions.Add(new ColumnDefinition());

                var dayName = new TextBlock() {
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    FontWeight = FontWeights.Bold,
                    Text = days[i]
                };
                Grid.SetColumn(dayName, i);
                dayNameContainer.Children.Add(dayName);
            }

            dayNameBorder = new Border() {
                BorderThickness = new Thickness(0,1,0,1),
                Padding = new Thickness(0,5,0,5),
                Margin = new Thickness(0,5,0,5),
                BorderBrush = Brushes.Coral,
                Child = dayNameContainer
            };

            currentDate = DateTime.Today;
            addDays(currentDate);
            addHeader();
            panel = new StackPanel() { Children = { headerContainer, dayNameBorder, dayContainer } };
            currentState = State.Day;

            pop = new Popup() {
                AllowsTransparency = true,
                StaysOpen = false,
                Placement = PlacementMode.Bottom,
                PlacementTarget = border,
                Child = panel
            };

            leftBorder.MouseUp += decrease;
            rightBorder.MouseUp += increase;
            header.MouseUp += resetState;
            iconBorder.MouseUp += showCalendar;

            EventManager.RegisterClassHandler(typeof(MonthYear), MonthYear.MouseUpEvent, new RoutedEventHandler(onMonthYearClicked), true);
            EventManager.RegisterClassHandler(typeof(Day), Day.MouseUpEvent, new RoutedEventHandler(onDayClicked), true);
        }

        void showCalendar(object sender, MouseButtonEventArgs e) => pop.IsOpen = true;

        void onMonthYearClicked(object sender, RoutedEventArgs e) {
            var element = e.Source as MonthYear;
            if(element.state == State.Month) {
                currentDate = new DateTime(currentDate.Year, element.number, 1);
                currentState = State.Day;
                header.Text = currentDate.ToString("MMMM, yyyy");
                panel.Children.Insert(1, dayNameBorder);
                addDays(currentDate);
            }
            else {
                currentDate = new DateTime(element.number, 1, 1);
                currentState = State.Month;
                header.Text = currentDate.ToString("yyyy");
                addMonths();
            }
        }

        void onDayClicked(object sender, RoutedEventArgs e) {
            var element = e.Source as Day;
            currentDate = new DateTime(currentDate.Year, currentDate.Month, element.day);
            foreach (Day item in dayContainer.Children) {
                if (item.IsSelected) {
                    item.IsSelected = false;
                    break;
                }
            }
            SelectedDate = currentDate;
            element.IsSelected = true;
            text.Text = currentDate.ToString("dd MMMM yyyy");
            pop.IsOpen = false;
        }

        void resetState(object sender, MouseButtonEventArgs e) {
            switch (currentState) {
                case State.Day:
                    currentState = State.Month;
                    header.Text = currentDate.ToString("yyyy");
                    panel.Children.Remove(dayNameBorder);
                    addMonths();
                    break;
                case State.Month:
                    currentState = State.Year;
                    header.Text = (currentDate.Year - 11) + " - " + currentDate.Year;
                    addYears();
                    break;
                case State.Year:
                    currentState = State.Day;
                    header.Text = currentDate.ToString("MMMM, yyyy");
                    panel.Children.Insert(1, dayNameBorder);
                    addDays(currentDate);
                    break;
            }
        }

        void increase(object sender, MouseButtonEventArgs e) {
            switch (currentState) {
                case State.Day:
                    currentDate = currentDate.AddMonths(1);
                    header.Text = currentDate.ToString("MMMM, yyyy");
                    addDays(currentDate);
                    break;
                case State.Month:
                    currentDate = currentDate.AddYears(1);
                    header.Text = currentDate.ToString("yyyy");
                    break;
                case State.Year:
                    currentDate = currentDate.AddYears(12);
                    header.Text = (currentDate.Year - 11) + " - " + currentDate.Year;
                    addYears();
                    break;
            }
        }

        void decrease(object sender, MouseButtonEventArgs e) {
            switch (currentState) {
                case State.Day:
                    currentDate = currentDate.AddMonths(-1);
                    header.Text = currentDate.ToString("MMMM, yyyy");
                    addDays(currentDate);
                    break;
                case State.Month:
                    currentDate = currentDate.AddYears(-1);
                    header.Text = currentDate.ToString("yyyy");
                    break;
                case State.Year:
                    currentDate = currentDate.AddYears(-12);
                    header.Text = (currentDate.Year - 11) + " - " + currentDate.Year;
                    addYears();
                    break;
            }
        }

        void addDays(DateTime currentDate) {
            dayContainer.Children.Clear();
            dayContainer.RowDefinitions.Clear();
            dayContainer.ColumnDefinitions.Clear();
            for (int i = 0; i < 7; i++) 
                dayContainer.ColumnDefinitions.Add(new ColumnDefinition());
            
            var numberOfDays = DateTime.DaysInMonth(currentDate.Year, currentDate.Month);
            var currentDay = 1;
            var dayOfWeek = (int)new DateTime(currentDate.Year, currentDate.Month, currentDay).DayOfWeek;
            var newDayOfWeek = dayOfWeek == 6 ? 0 : dayOfWeek + 1;

            int requiredRows = 1;
            var remainingDays = numberOfDays - 7 + newDayOfWeek;
            requiredRows += remainingDays / 7;
            var remainder = remainingDays % 7;
            if (remainder != 0) requiredRows++;

            var today = DateTime.Today;

            for (int i = 0; i < requiredRows; i++) {
                dayContainer.RowDefinitions.Add(new RowDefinition());
                int k = currentDay == 1 ? newDayOfWeek : 0;
                for (int j = k; j < 7; j++) {
                    if(currentDay < numberOfDays + 1) {
                        var day = new Day(currentDay);

                        if(currentDate == SelectedDate) {
                            if (currentDay == currentDate.Day)
                                day.IsSelected = true;
                        }

                        if (currentDate == today) {
                            if (currentDay == today.Day)
                                day.IsToday = true;
                        }

                        Grid.SetRow(day, i);
                        Grid.SetColumn(day, j);
                        dayContainer.Children.Add(day);
                        currentDay++;
                    }
                }
            }
        }

        void addMonths() {
            dayContainer.Children.Clear();
            dayContainer.RowDefinitions.Clear();
            dayContainer.ColumnDefinitions.Clear();
            for (int i = 0; i < 3; i++)
                dayContainer.ColumnDefinitions.Add(new ColumnDefinition());

            int currentMonth = 1;
            for (int i = 0; i < 4; i++) {
                dayContainer.RowDefinitions.Add(new RowDefinition());
                for (int j = 0; j < 3; j++) {
                    var month = new MonthYear(currentMonth++, currentState);
                    Grid.SetRow(month, i);
                    Grid.SetColumn(month, j);
                    dayContainer.Children.Add(month);
                }
            }
        }

        void addYears() {
            int currentYear = currentDate.Year - 11;
            dayContainer.Children.Clear();
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 3; j++) {
                    var year = new MonthYear(currentYear++, currentState);
                    Grid.SetRow(year, i);
                    Grid.SetColumn(year, j);
                    dayContainer.Children.Add(year);
                }
            }
        }

        void addHeader() {
            header = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold,
                FontSize = 16,
                Text = currentDate.ToString("MMMM, yyyy")
            };
            Grid.SetColumn(header, 1);
            leftIcon = new Path() {
                Fill = Brushes.Black,
                Stretch = Stretch.Uniform,
                Data = Geometry.Parse(leftArrow)
            };
            rightIcon = new Path() {
                Fill = Brushes.Black,
                Stretch = Stretch.Uniform,
                Data = Geometry.Parse(rightArrow)
            };
            leftBorder = new Border() {
                Background = Brushes.Transparent,
                Child = leftIcon
            };
            rightBorder = new Border() {
                Background = Brushes.Transparent,
                Child = rightIcon
            };
            Grid.SetColumn(rightBorder, 2);
            headerContainer = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { leftBorder, header, rightBorder }
            };
        }

        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
        protected override Size MeasureOverride(Size availableSize) {
            dayContainer.Width = 300;
            dayContainer.Height = 250;
            border.Width = availableSize.Width;
            border.Measure(availableSize);
            return border.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(border.DesiredSize));
            return border.DesiredSize;
        }

        #region mess
        public DateTime? SelectedDate {
            get { return (DateTime?)GetValue(SelectedDateProperty); }
            set { SetValue(SelectedDateProperty, value); }
        }

        public static readonly DependencyProperty SelectedDateProperty =
            DependencyProperty.Register("SelectedDate", typeof(DateTime?), typeof(DayPicker), new PropertyMetadata(null));
        #endregion
    }

    class Day : FrameworkElement
    {
        Size size;
        Border border;
        TextBlock text;
        SolidColorBrush textBrush, borderBrush;
        ColorAnimation textAnim, borderBrushAnim;
        ThicknessAnimation borderThicknessAnim;

        public int day;
        bool isSelected, isToday;
        public bool IsSelected {
            get { return isSelected; }
            set { 
                isSelected = value;
                if (isSelected) {
                    borderBrushAnim.To = Colors.LightGray;
                    borderThicknessAnim.To = new Thickness(4);
                }
                else {
                    borderBrushAnim.To = IsToday ? Colors.LightSeaGreen : Colors.Coral;
                    borderThicknessAnim.To = new Thickness(0);
                }
                borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
                border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
            }
        }
        public bool IsToday {
            get { return isToday; }
            set { 
                isToday = value;
                borderBrushAnim.To = Colors.LightSeaGreen;
                borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
            }
        }


        public Day(int day) {
            this.day = day;
            size = new Size(40, 40);
            textBrush = new SolidColorBrush(Colors.Black);
            borderBrush = new SolidColorBrush(Colors.Coral);
            text = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = textBrush,
                FontSize = 15,
                Text = day.ToString()
            };
            border = new Border() {
                CornerRadius = new CornerRadius(20),
                Background = borderBrush,
                BorderBrush = Brushes.Coral,
                Child = text
            };
            AddVisualChild(border);

            var duration = TimeSpan.FromSeconds(1);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            textAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            borderBrushAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            borderThicknessAnim = new ThicknessAnimation() {
                Duration = duration,
                EasingFunction = ease
            };

            Loaded += scaleUp;
        }

        void scaleUp(object sender, RoutedEventArgs e) {
            RenderTransform = new ScaleTransform(1, 1, ActualWidth / 2, ActualHeight / 2);
            var anim = new DoubleAnimation() {
                From = 0,
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
            RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }

        void animate() {
            textBrush.BeginAnimation(SolidColorBrush.ColorProperty, textAnim);
            borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
            border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            textAnim.To = Colors.White;
            borderBrushAnim.To = Colors.Black;
            borderThicknessAnim.To = new Thickness(2);
            animate();
            text.FontWeight = FontWeights.Bold;
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            textAnim.To = Colors.Black;
            if (IsSelected) {
                borderBrushAnim.To = Colors.LightGray;
                borderThicknessAnim.To = new Thickness(4);
            }
            else {
                borderBrushAnim.To = IsToday ? Colors.LightSeaGreen : Colors.Coral;
                borderThicknessAnim.To = new Thickness(0);
            }
            animate();
            text.FontWeight = FontWeights.Normal;
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Width = size.Width;
            border.Height = size.Height;
            border.Measure(size);
            return size;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(size));
            return size;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
    }

    class MonthYear : FrameworkElement
    {
        Size size;
        Border border;
        TextBlock text;
        SolidColorBrush textBrush, borderBrush;
        ColorAnimation textAnim, borderBrushAnim;
        ThicknessAnimation borderThicknessAnim;

        public int number;
        public State state;

        public MonthYear(int number, State state) {
            this.number = number;
            this.state = state;
            size = new Size(80, 40);
            textBrush = new SolidColorBrush(Colors.Black);
            borderBrush = new SolidColorBrush(Colors.Coral);
            text = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = textBrush,
                FontSize = 15,
                Text = state == State.Month ?
                    CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(number) :
                    number.ToString()
            };
            border = new Border() {
                CornerRadius = new CornerRadius(20),
                Background = borderBrush,
                BorderBrush = Brushes.Coral,
                Child = text
            };
            AddVisualChild(border);

            var duration = TimeSpan.FromSeconds(1);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            textAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            borderBrushAnim = new ColorAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            borderThicknessAnim = new ThicknessAnimation() {
                Duration = duration,
                EasingFunction = ease
            };

            Loaded += scaleUp;
        }

        void scaleUp(object sender, RoutedEventArgs e) {
            RenderTransform = new SkewTransform();
            var anim = new DoubleAnimation() {
                From = 45,
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            RenderTransform.BeginAnimation(SkewTransform.AngleXProperty, anim);
            RenderTransform.BeginAnimation(SkewTransform.AngleYProperty, anim);
        }

        void animate() {
            textBrush.BeginAnimation(SolidColorBrush.ColorProperty, textAnim);
            borderBrush.BeginAnimation(SolidColorBrush.ColorProperty, borderBrushAnim);
            border.BeginAnimation(Border.BorderThicknessProperty, borderThicknessAnim);
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            textAnim.To = Colors.White;
            borderBrushAnim.To = Colors.Black;
            borderThicknessAnim.To = new Thickness(2);
            animate();
            text.FontWeight = FontWeights.Bold;
        }
        protected override void OnMouseLeave(MouseEventArgs e) {
            textAnim.To = Colors.Black;
            borderBrushAnim.To = Colors.Coral;
            borderThicknessAnim.To = new Thickness(0);
            animate();
            text.FontWeight = FontWeights.Normal;
        }
        protected override Size MeasureOverride(Size availableSize) {
            border.Width = size.Width;
            border.Height = size.Height;
            border.Measure(size);
            return size;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            border.Arrange(new Rect(size));
            return size;
        }
        protected override Visual GetVisualChild(int index) => border;
        protected override int VisualChildrenCount => 1;
    }

    enum State
    {
        Day,
        Month,
        Year
    }
}
