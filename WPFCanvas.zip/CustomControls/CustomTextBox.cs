﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    class CustomTextBox : FrameworkElement
    {
        double infoIconSize, iconSize;
        bool isHintMoved;
        TextBox content;
        TextBlock hintBlock, counter, errorMessage;
        Separator separator;
        Grid container;
        Border outline;
        SolidColorBrush normalBrush, errorBrush, infoIconBrush;
        ScaleTransform scaleHint;
        TranslateTransform translateHint;
        Path icon, infoIcon;
        Geometry errorIcon, validIcon;
        DoubleAnimation translateHintAnim, scaleHintAnim;
        ColorAnimation infoIconColorAnim;
        ObjectAnimationUsingKeyFrames infoIconAnim;

        string hint;
        public string Hint {
            get { return hint; }
            set { hint = value; hintBlock.Text = value; }
        }

        private bool isMultiline;

        public bool IsMultiline {
            get { return isMultiline; }
            set { 
                isMultiline = value;
                content.AcceptsReturn = true;
                content.TextWrapping = TextWrapping.Wrap;
                content.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
                content.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
                content.Height = 75;

                icon.VerticalAlignment = VerticalAlignment.Top;
                infoIcon.VerticalAlignment = VerticalAlignment.Top;
                hintBlock.VerticalAlignment = VerticalAlignment.Top;
            }
        }

        public CustomTextBox() {
            normalBrush = Brushes.LightBlue;
            errorBrush = Brushes.Red;
            infoIconBrush = new SolidColorBrush();
            iconSize = 32;
            infoIconSize = 16;

            content = new TextBox() { BorderThickness = new Thickness(0) };
            Grid.SetColumn(content, 1);

            separator = new Separator() {
                BorderBrush = normalBrush,
                BorderThickness = new Thickness(1),
                Visibility = Visibility.Collapsed
            };
            Grid.SetRow(separator, 1);
            Grid.SetColumnSpan(separator, 3);

            scaleHint = new ScaleTransform();
            translateHint = new TranslateTransform();
            hintBlock = new TextBlock() {
                Foreground = Brushes.Gray,
                Background = Brushes.White,
                Padding = new Thickness(10, 0, 10, 0),
                HorizontalAlignment = HorizontalAlignment.Left,
                RenderTransform = new TransformGroup() { Children = { scaleHint, translateHint } }
            };
            Grid.SetColumn(hintBlock, 1);

            errorMessage = new TextBlock() { Visibility = Visibility.Collapsed };
            Grid.SetRow(errorMessage, 2);
            Grid.SetColumnSpan(errorMessage, 2);

            counter = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Right,
                Visibility = Visibility.Collapsed
            };
            Grid.SetRow(counter, 2);
            Grid.SetColumn(counter, 1);
            Grid.SetColumnSpan(counter, 2);

            validIcon = Geometry.Parse("M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z");
            errorIcon = Geometry.Parse("M13,13H11V7H13M13,17H11V15H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z");
            infoIcon = new Path() {
                Fill = infoIconBrush,
                Stretch = Stretch.Uniform,
                Width = infoIconSize,
                Height = Width,
                HorizontalAlignment = HorizontalAlignment.Right,
                Visibility = Visibility.Collapsed
            };
            Grid.SetColumn(infoIcon, 2);

            icon = new Path() {
                Fill = Brushes.Black,
                Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Left,
                Width = iconSize,
                Height = Width
            };
           
            container = new Grid() {
                Margin = new Thickness(0, 10, 0, 0),
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto}
                },
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Star) },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = {icon, content, hintBlock, separator, errorMessage, counter, infoIcon}
            };

            outline = new Border() {
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                BorderBrush = normalBrush,
                Padding = new Thickness(10, 5, 10, 0),
                Child = container
            };

            AddVisualChild(outline);

            translateHintAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            scaleHintAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            infoIconAnim = new ObjectAnimationUsingKeyFrames();
            infoIconColorAnim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };

            content.TextChanged += onContentChanged;
            hintBlock.MouseEnter += changeCursor;
        }

        void changeCursor(object sender, MouseEventArgs e) => content.Focus();

        void onContentChanged(object sender, TextChangedEventArgs e) {
            var length = content.Text.Length;
            counter.Text = length + "/" + content.MaxLength;
            Text = content.Text;
        }

        protected override Visual GetVisualChild(int index) => outline;
        protected override int VisualChildrenCount => 1;
        protected override Size MeasureOverride(Size availableSize) {
            outline.Width = availableSize.Width;
            outline.Measure(availableSize);
            return outline.DesiredSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            outline.Arrange(new Rect(outline.DesiredSize));
            return finalSize;
        }
        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
            if (content.Text.Length == 0 && !isHintMoved) {
                isHintMoved = true;
                scaleHintAnim.To = 0.9;
                translateHintAnim.To = -25;

                translateHint.BeginAnimation(TranslateTransform.YProperty, translateHintAnim);
                scaleHint.BeginAnimation(ScaleTransform.ScaleXProperty, scaleHintAnim);
                scaleHint.BeginAnimation(ScaleTransform.ScaleYProperty, scaleHintAnim);
            }
        }
        protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
            if (content.Text.Length == 0 && isHintMoved) {
                isHintMoved = false;
                scaleHintAnim.To = 1;
                translateHintAnim.To = 0;

                translateHint.BeginAnimation(TranslateTransform.YProperty, translateHintAnim);
                scaleHint.BeginAnimation(ScaleTransform.ScaleXProperty, scaleHintAnim);
                scaleHint.BeginAnimation(ScaleTransform.ScaleYProperty, scaleHintAnim);
            }
        }

        #region mess
        public int MaxLength {
            get { return (int)GetValue(MaxLengthProperty); }
            set { SetValue(MaxLengthProperty, value); }
        }

        public string ErrorMessage {
            get { return (string)GetValue(ErrorMessageProperty); }
            set { SetValue(ErrorMessageProperty, value); }
        }

        public string Text {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }


        public string IconGeometry {
            get { return (string)GetValue(IconGeometryProperty); }
            set { SetValue(IconGeometryProperty, value); }
        }

        public static readonly DependencyProperty IconGeometryProperty =
            DependencyProperty.Register("IconGeometry", typeof(string), typeof(CustomTextBox), new PropertyMetadata(null, onIconGeometryChanged));

        public static readonly DependencyProperty ErrorMessageProperty =
            DependencyProperty.Register("ErrorMessage", typeof(string), typeof(CustomTextBox), new PropertyMetadata(null, onErrorMessageChanged));

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(CustomTextBox), new PropertyMetadata(null));

        public static readonly DependencyProperty MaxLengthProperty =
            DependencyProperty.Register("MaxLength", typeof(int), typeof(CustomTextBox), new PropertyMetadata(0, onMaxLengthChanged));

        static void onMaxLengthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as CustomTextBox;
            if (o.counter.Visibility == Visibility.Collapsed) {
                o.counter.Visibility = Visibility.Visible;
                o.separator.Visibility = Visibility.Visible;
                o.infoIcon.Visibility = Visibility.Visible;
            }
            o.content.MaxLength = (int)e.NewValue;
        }

        static void onErrorMessageChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as CustomTextBox;
            if(o.errorMessage.Visibility == Visibility.Collapsed) {
                o.errorMessage.Visibility = Visibility.Visible;
                o.separator.Visibility = Visibility.Visible;
                o.infoIcon.Visibility = Visibility.Visible;
            }
            var message = e.NewValue.ToString();
            o.errorMessage.Text = message;
            o.infoIconAnim.KeyFrames.Clear();
            if (!string.IsNullOrWhiteSpace(message)) {
                o.outline.BorderBrush = o.errorBrush;
                o.separator.BorderBrush = o.errorBrush;

                o.infoIconColorAnim.To = Colors.Red;
                o.infoIconAnim.KeyFrames.Add(new DiscreteObjectKeyFrame(o.errorIcon, TimeSpan.FromSeconds(0.5)));
                o.infoIcon.BeginAnimation(Path.DataProperty, o.infoIconAnim);
                o.infoIconBrush.BeginAnimation(SolidColorBrush.ColorProperty, o.infoIconColorAnim);
            }
            else {
                o.outline.BorderBrush = o.normalBrush;
                o.separator.BorderBrush = o.normalBrush;

                o.infoIconColorAnim.To = Colors.Green;
                o.infoIconAnim.KeyFrames.Add(new DiscreteObjectKeyFrame(o.validIcon, TimeSpan.FromSeconds(0.5)));
                o.infoIcon.BeginAnimation(Path.DataProperty, o.infoIconAnim);
                o.infoIconBrush.BeginAnimation(SolidColorBrush.ColorProperty, o.infoIconColorAnim);
            }
        }

        static void onIconGeometryChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as CustomTextBox;
            o.icon.Data = Geometry.Parse(e.NewValue.ToString());
        }
        #endregion
    }
}
