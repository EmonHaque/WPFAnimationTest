﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Animation;
using WPFCanvas.ViewModel;

namespace WPFCanvas.CustomControls
{
    class TransitioningPanel : Panel
    {
        double navWidth = 32;
        int selectedIndex, newIndex;
        bool isAnimating;
        List<UserControl> userControls;
        List<RoundButton> buttons;
        Border border;
        Command transit;
        DoubleAnimation getIn, getOut;

        public TransitioningPanel() {
            userControls = new List<UserControl>();
            buttons = new List<RoundButton>();
            border = new Border() { 
                Background = Brushes.LightGray, 
                Width = navWidth,
                CornerRadius = new CornerRadius(0, 0, 0, 10)
            };
            SetZIndex(border, 1);
            Children.Add(border);
            transit = new Command(go, (o) => true);

            var duration = TimeSpan.FromSeconds(2);
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            getIn = new DoubleAnimation() {
                To = 0,
                Duration = duration,
                EasingFunction = ease
            };
            getOut = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = ease
            };
            getOut.Completed += reset;
        }

        void reset(object sender, EventArgs e) {
            userControls[selectedIndex].Visibility = Visibility.Hidden;
            selectedIndex = newIndex;
            isAnimating = buttons[selectedIndex].IsRunning = false;
        }

        void go(object o) {
            var index = (int)o;
            if(!isAnimating && index != selectedIndex) {
                isAnimating = true;
                buttons[index].IsRunning = true;
                newIndex = index;
                userControls[selectedIndex].RenderTransform.BeginAnimation(TranslateTransform.XProperty, getOut);
                userControls[newIndex].RenderTransform.BeginAnimation(TranslateTransform.XProperty, getIn);
                userControls[newIndex].Visibility = Visibility.Visible;

                userControls[newIndex].DataContext = null;
                userControls[newIndex].DataContext = DataContext as MainViewModel;
            }
        }

        protected override Size ArrangeOverride(Size finalSize) {
            getIn.From = navWidth - finalSize.Width;
            getOut.To = finalSize.Width - navWidth;
            var y = 0d;

            foreach (RoundButton item in buttons) {
                item.Width = item.Height = navWidth;
                item.Measure(finalSize);
                item.Arrange(new Rect(new Point(0, y), item.DesiredSize));
                y += navWidth;
            }

            foreach (UserControl item in userControls) {
                item.Width = finalSize.Width - navWidth;
                item.Height = finalSize.Height;
                item.Measure(finalSize);
                item.Arrange(new Rect(new Point(navWidth, 0), item.DesiredSize));
                if (!userControls.ElementAt(selectedIndex).Equals(item))
                    item.Visibility = Visibility.Hidden;
            }

            border.Height = finalSize.Height;
            border.Measure(finalSize);
            border.Arrange(new Rect(new Point(0, 0), border.DesiredSize));
            return finalSize;
        }

        protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved) {
            if(visualAdded is UserControl) {
                var control = visualAdded as UserControl;
                control.RenderTransform = new TranslateTransform(0, 0);
                userControls.Add(control);
                SetZIndex(control, 0);

                var button = new RoundButton(24);
                button.Icon = (control as IHaveIcon).Icon;
                buttons.Add(button);
                button.Command = transit;
                button.CommandParameter = buttons.IndexOf(button);
                Children.Add(button);
                SetZIndex(button, 2);
            }
        }
    }
}
