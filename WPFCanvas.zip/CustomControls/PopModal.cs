﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace WPFCanvas.CustomControls
{
    class PopModal : Window
    {
        TextBlock titleText, messageText;
        Grid content;
        string title;
        public new string Title {
            get { return title; }
            set { title = value; titleText.Text = value; }
        }
        string message;
        public string Message {
            get { return message; }
            set { message = value; messageText.Text = value; }
        }

        public PopModal() {
            Owner = App.Current.MainWindow;
            Width = Owner.ActualWidth;
            Height = Owner.ActualHeight;
            ResizeMode = ResizeMode.NoResize;
            WindowStyle = WindowStyle.None;
            WindowState = Owner.WindowState == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            AllowsTransparency = true;
            ShowInTaskbar = false;
            Background = new SolidColorBrush(Color.FromArgb(100, 0, 0, 100));

            var titleBar = new Border() {
                Background = Brushes.LightGray,
                Child = new TextBlock() {
                    VerticalAlignment = VerticalAlignment.Center,
                    FontSize = 32,
                    Margin = new Thickness(10, 0, 0, 0),
                    FontWeight = FontWeights.Bold
                }
            };
            titleText = (TextBlock)titleBar.Child;

            messageText = new TextBlock() {
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 16,
                Margin = new Thickness(10),
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetRow(messageText, 1);
            var okButton = new Button() { Content = "Ok", Width = 100 };
            var cancelButton = new Button() { Content = "Cancel", Width = 100 };
            okButton.Click += (s, e) => { DialogResult = true; Close(); };
            cancelButton.Click += (s, e) => { DialogResult = false; Close(); };

            var buttonsPanel = new StackPanel() {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Right,
                Children = { okButton, cancelButton }
            };
            Grid.SetRow(buttonsPanel, 2);
            content = new Grid() {
                Background = Brushes.White,
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto }
                },
                Children = { titleBar, messageText, buttonsPanel}
            };
            Grid.SetRow(content, 1);
            Content = new Grid() {
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
                Children = {content}
            };
            Loaded += animate;
        }

        void animate(object sender, RoutedEventArgs e) {
            RenderTransform = new ScaleTransform(1, 1, ActualWidth / 2, ActualHeight / 2);
            var anim = new DoubleAnimation() {
                From = 0,
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }
    }
}
