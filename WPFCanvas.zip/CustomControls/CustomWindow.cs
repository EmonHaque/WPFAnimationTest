﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shell;
using WPFCanvas.UserControls;
using WPFCanvas.ViewModel;

namespace WPFCanvas.CustomControls
{
    class CustomWindow : Window
    {
        Border windowBorder, titleBar;
        Grid contentGrid, titlebarIconGrid;
        double radius = 10;

        string minimizeGeo = "M17,13H7V11H17M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z";
        string maximizeGeo = "M22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12M7.4,15.4L12,10.8L16.6,15.4L18,14L12,8L6,14L7.4,15.4Z";
        string closeGeo = "M2 12C2 9.21 3.64 6.8 6 5.68V3.5C2.5 4.76 0 8.09 0 12S2.5 19.24 6 20.5V18.32C3.64 17.2 2 14.79 2 12M15 3C10.04 3 6 7.04 6 12S10.04 21 15 21 24 16.96 24 12 19.96 3 15 3M20 15.59L18.59 17L15 13.41L11.41 17L10 15.59L13.59 12L10 8.41L11.41 7L15 10.59L18.59 7L20 8.41L16.41 12L20 15.59Z";

        public CustomWindow() {
            WindowChrome.SetWindowChrome(this, new WindowChrome() {
                ResizeBorderThickness = new Thickness(0,0,5,5),
                CaptionHeight = 0
            });

            Height = 500;
            Width = 700;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;

            addTitleIcons();

            titleBar = new Border() {
                CornerRadius = new CornerRadius(radius, radius, 0, 0),
                Background = Brushes.LightGray,
                Height = 32,
                Effect = new DropShadowEffect() { BlurRadius = 5, Opacity = 0.5, Direction = -90 },
                Child = titlebarIconGrid
            };

            var tPanel = new TransitioningPanel() {
                DataContext = new MainViewModel(),
                Children = {
                    new UC1(),
                    new UC2(),
                    new UC3()
                }
            };
            Grid.SetRow(tPanel, 1);
            contentGrid = new Grid() {
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { titleBar, tPanel }
            };
            windowBorder = new Border() {
                Background = Brushes.White,
                CornerRadius = new CornerRadius(radius),
                BorderThickness = new Thickness(2),
                BorderBrush = Brushes.LightBlue,
                Child = contentGrid
            };
            AddVisualChild(windowBorder);

            titleBar.MouseLeftButtonDown += resetWindowState;
            titleBar.MouseMove += moveWindow;
        }

        void moveWindow(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        void resetWindowState(object sender, MouseButtonEventArgs e) {
            if (e.ClickCount == 2)
                handleResize();
        }

        void addTitleIcons() {
            var close = new ActionButton() {
                WidthAndHeight = 24,
                ToolTip = "Close",
                Margin = new Thickness(0, 0, 5, 0),
                PathData = closeGeo,
                Command = Application.Current.Shutdown
            };
            var maximize = new ActionButton() {
                WidthAndHeight = 24,
                ToolTip = "Maximize/Restore",
                Margin = new Thickness(0, 0, 5, 0),
                PathData = maximizeGeo,
                Command = handleResize
            };
            var minimize = new ActionButton() {
                WidthAndHeight = 24,
                ToolTip = "Minimize",
                Margin = new Thickness(0, 0, 5, 0),
                PathData = minimizeGeo,
                Command = () => WindowState = WindowState.Minimized
            };
            Grid.SetColumn(close, 3);
            Grid.SetColumn(maximize, 2);
            Grid.SetColumn(minimize, 1);

            titlebarIconGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
                Children = { close, maximize, minimize }
            };
        }

        void handleResize() {
            if(WindowState == WindowState.Maximized) {
                ResizeMode = ResizeMode.CanResizeWithGrip;
                WindowState = WindowState.Normal;
            }
            else {
                ResizeMode = ResizeMode.NoResize;
                WindowState = WindowState.Maximized;
            }
        }

        protected override Size MeasureOverride(Size availableSize) {
            windowBorder.Width = availableSize.Width;
            windowBorder.Height = availableSize.Height;
            windowBorder.Measure(availableSize);
            return windowBorder.DesiredSize;
        }
        protected override Size ArrangeOverride(Size arrangeBounds) {
            windowBorder.Arrange(new Rect(windowBorder.DesiredSize));
            return arrangeBounds;
        }
        protected override Visual GetVisualChild(int index) => windowBorder;
        protected override int VisualChildrenCount => 1;
    }
}
