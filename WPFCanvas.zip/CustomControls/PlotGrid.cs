﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    class Plot : FrameworkElement
    {
        Canvas plotArea;
        TranslateTransform translate;
        PlotGrid grid;
        Point center;
        Polyline xSquare, xCube, xSine;
        TextBox textField;
        ListBox list;
        Grid container;

        public Plot() {
            initiGrid();
            initPlotArea();
            textField = new TextBox();
            list = new ListBox();

            var outline = new Rectangle() {
                StrokeThickness = 1,
                Stroke = Brushes.Black
            };
            var plotContainer = new Grid() {
                ClipToBounds = true,
                Children = { outline, grid, plotArea }
            };

            Grid.SetRow(textField, 1);
            Grid.SetColumnSpan(textField, 2);
            Grid.SetColumn(plotContainer, 1);
            
            container = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(100)},
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star)}
                },
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(){Height = GridLength.Auto}
                },
                Children = {list, textField, plotContainer}
            };

            AddVisualChild(container);

            textField.KeyUp += onEnter;
            list.KeyUp += delete;
        }

        void delete(object sender, KeyEventArgs e) {
            var i = list.SelectedItem;
            if (i != null && i.ToString() == "x*x") {
                plotArea.Children.Remove(xSquare);
                list.Items.Remove(i);
            }
            if (i != null && i.ToString() == "x*x*x") {
                plotArea.Children.Remove(xCube);
                list.Items.Remove(i);
            }
            if (i != null && i.ToString() == "sine") {
                plotArea.Children.Remove(xSine);
                list.Items.Remove(i);
            }
        }

        void onEnter(object sender, KeyEventArgs e) {
            if(e.Key == Key.Enter) {
                var eq = textField.Text;
                if (eq == "x*x") drawSquare();
                else if (eq == "x*x*x") drawCube();
                else if (eq == "sine") drawSine();

                list.Items.Add(eq);
                textField.Text = "";
            }
        }

        void initiGrid() {
            grid = new PlotGrid();
            grid.CenterChanged += onCenterChanged;
        }

        void onCenterChanged(Point center) {
            this.center = center;
            translate.Y = -plotArea.ActualHeight + center.Y;
            translate.X = center.X;
        }

        void initPlotArea() {
            translate = new TranslateTransform();
            plotArea = new Canvas() { 
                LayoutTransform = new ScaleTransform() { ScaleY = -1},
                RenderTransform = translate
            };
        }

        void drawSquare() {
            xSquare = new Polyline() { Stroke = Brushes.Black, StrokeThickness = 1 };
            plotArea.Children.Add(xSquare);

            var squared = new PointCollection();
            var step = 0.1;
            var segments = (grid.xMax - grid.xMin) / step;
            var xPosition = -center.X;
            var xStep = plotArea.ActualWidth / segments;
            var transform = plotArea.ActualHeight / (grid.yMax - grid.yMin);
            for (double x = grid.xMin; x < grid.xMax; x += step) {
                var y = x * x;
                var transformedY = transform * y;
                var point = new Point(xPosition, transformedY);
                squared.Add(point);
                xPosition += xStep;
            }
            xSquare.Points = squared;
        }

        void drawCube() {
            xCube = new Polyline() { Stroke = Brushes.Red, StrokeThickness = 1 };
            plotArea.Children.Add(xCube);

            var cubed = new PointCollection();
            var step = 0.1;
            var segments = (grid.xMax - grid.xMin) / step;
            var xPosition = -center.X;
            var xStep = plotArea.ActualWidth / segments;
            var transform = plotArea.ActualHeight / (grid.yMax - grid.yMin);
            xPosition = -center.X;
            for (double x = grid.xMin; x < grid.xMax; x += step) {
                var y = x * x * x;
                var transformedY = transform * y;
                var point = new Point(xPosition, transformedY);
                cubed.Add(point);
                xPosition += xStep;
            }
            xCube.Points = cubed;
        }

        void drawSine() {
            xSine = new Polyline() { Stroke = Brushes.Green, StrokeThickness = 1 };
            plotArea.Children.Add(xSine);

            var sine = new PointCollection();
            var step = 0.1;
            var segments = (grid.xMax - grid.xMin) / step;
            var xPosition = -center.X;
            var xStep = plotArea.ActualWidth / segments;
            var transform = plotArea.ActualHeight / (grid.yMax - grid.yMin);
            xPosition = -center.X;
            for (double x = grid.xMin; x < grid.xMax; x += step) {
                var y = Math.Sin(x);
                var transformedY = transform * y;
                var point = new Point(xPosition, transformedY);
                sine.Add(point);
                xPosition += xStep;
            }
            xSine.Points = sine;
        }

        protected override Size ArrangeOverride(Size finalSize) {
            container.Width = finalSize.Width;
            container.Height = finalSize.Height;
            container.Measure(finalSize);
            container.Arrange(new Rect(finalSize));
            return finalSize;
        }
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
            translate.Y = -plotArea.ActualHeight + center.Y;
        }
        protected override Visual GetVisualChild(int index) => container;
        protected override int VisualChildrenCount => 1;
    }

    class PlotGrid : FrameworkElement
    {
        VisualCollection children;
        Line x, y;
        Pen pen, dashPen;
        Rectangle hitArea;
        Point start, end;
        double zoomStartX, zoomStartY;
        bool isX, minor;

        public Point Center;
        public double xMin, xMax, yMin, yMax, step, zoomX, zoomY;
        public event Action<Point> CenterChanged;

        public PlotGrid() {
            pen = new Pen(Brushes.LightGray, 1);
            dashPen = new Pen() {
                Brush = Brushes.LightGray,
                Thickness = 1,
                DashCap = PenLineCap.Round,
                DashStyle = DashStyles.DashDotDot
            };
            step = 50;
            zoomX = zoomY = 1;
            x = new Line() { Stroke = Brushes.LightBlue, StrokeThickness = 2 };
            y = new Line() { Stroke = Brushes.LightBlue, StrokeThickness = 2, Tag ="Y" };
            hitArea = new Rectangle() { Fill = Brushes.Transparent };
            children = new VisualCollection(this) { hitArea, x, y };
            Loaded += onLoaded;

            x.MouseEnter += (s, e) => x.StrokeThickness = 6;
            x.MouseLeave += (s, e) => x.StrokeThickness = 2;
            y.MouseEnter += (s, e) => y.StrokeThickness = 6;
            y.MouseLeave += (s, e) => y.StrokeThickness = 2;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            Center.X = ActualWidth / 2;
            Center.Y = ActualHeight / 2;
            InvalidateMeasure();
            InvalidateVisual();
        }
        FormattedText formatText(string text) {
            return new FormattedText(
                    text,
                    Thread.CurrentThread.CurrentCulture,
                    FlowDirection.LeftToRight,
                    new Typeface(SystemFonts.MessageFontFamily, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal),
                    11,
                    Brushes.Black,
                    VisualTreeHelper.GetDpi(this).PixelsPerDip
                );
        }
        protected override Size MeasureOverride(Size availableSize) {
            x.Y1 = x.Y2 = Center.Y;
            x.X2 = availableSize.Width;
            y.X1 = y.X2 = Center.X;
            y.Y2 = availableSize.Height;
            x.Measure(availableSize);
            y.Measure(availableSize);

            hitArea.Width = availableSize.Width;
            hitArea.Height = availableSize.Height;
            hitArea.Measure(availableSize);
            return availableSize;
        }
        protected override Size ArrangeOverride(Size finalSize) {
            x.Arrange(new Rect(x.DesiredSize));
            y.Arrange(new Rect(y.DesiredSize));
            hitArea.Arrange(new Rect(hitArea.DesiredSize));
            return finalSize;
        }
        protected override void OnRender(DrawingContext dc) {
            xMin = xMax = yMin = yMax = 0;
            double remainder;
            var x = Center.X + step;
            while (x < ActualWidth) {
                dc.DrawLine(pen, new Point(x, 0), new Point(x, ActualHeight));
                dc.DrawText(formatText((xMax + zoomX).ToString("N2")), new Point(x, Center.Y));
                if(minor) dc.DrawLine(dashPen, new Point(x-step/2, 0), new Point(x - step / 2, ActualHeight));

                x += step;
                xMax += zoomX;
            }
            remainder = ActualWidth - Center.X - step * xMax / zoomX;
            if (remainder > 0) xMax += remainder / step * zoomX;

            x = Center.X - step;
            while(x > 0) {
                dc.DrawLine(pen, new Point(x, 0), new Point(x, ActualHeight));
                dc.DrawText(formatText((xMin - zoomX).ToString("N2")), new Point(x, Center.Y));
                if (minor) dc.DrawLine(dashPen, new Point(x + step / 2, 0), new Point(x + step / 2, ActualHeight));

                x -= step;
                xMin -= zoomX;
            }
            remainder = Center.X + step * xMin / zoomX;
            if (remainder > 0) xMin -= remainder / step * zoomX;

            double maxPossibleX = ActualWidth / step * zoomX;
            if (xMax == 0) xMax = xMin + maxPossibleX;
            if (xMin == 0) xMin = xMax - maxPossibleX;

            var y = Center.Y + step;
            while (y < ActualHeight) {
                dc.DrawLine(pen, new Point(0, y), new Point(ActualWidth, y));
                dc.DrawText(formatText((yMin - zoomY).ToString("N2")), new Point(Center.X, y));
                if(minor) dc.DrawLine(dashPen, new Point(0, y-step/2), new Point(ActualWidth, y - step / 2));

                y += step;
                yMin -= zoomY;
            }
            remainder = ActualHeight - Center.Y + step * yMin / zoomY;
            if (remainder > 0) yMin -= remainder / step * zoomY;

            y = Center.Y - step;
            while (y > 0) {
                dc.DrawLine(pen, new Point(0, y), new Point(ActualWidth, y));
                dc.DrawText(formatText((yMax + zoomY).ToString("N2")), new Point(Center.X, y));
                if (minor) dc.DrawLine(dashPen, new Point(0, y + step / 2), new Point(ActualWidth, y + step / 2));

                y -= step;
                yMax += zoomY;
            }
            remainder = Center.Y - step * yMax / zoomY;
            if (remainder > 0) yMax += remainder / step * zoomY;

            double maxPossibleY = ActualHeight / step * zoomY;
            if (yMax == 0) yMax = yMin + maxPossibleY;
            if (yMin == 0) yMin = yMax - maxPossibleY;

            CenterChanged?.Invoke(Center);
        }
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) => start = e.GetPosition(this);
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            end = e.GetPosition(this);
            Center.X += end.X - start.X;
            Center.Y += end.Y - start.Y;
            InvalidateMeasure();
            InvalidateVisual();
        }
        protected override void OnMouseWheel(MouseWheelEventArgs e) {
            minor = !minor;
            if (!minor) {
                if (e.Delta > 0) {
                    zoomX += 0.1;
                    zoomY += 0.1;
                }
                else {
                    if (Math.Round(zoomX, 2) > 0.1)
                        zoomX -= 0.1;
                    if (Math.Round(zoomY, 2) > 0.1)
                        zoomY -= 0.1;
                }
            }
            InvalidateMeasure();
            InvalidateVisual();
        }
        protected override void OnMouseMove(MouseEventArgs e) {
            if(e.Source is Line) {
                if ((e.Source as Line).Tag == null) isX = true;
                else isX = false;

                if(e.LeftButton == MouseButtonState.Pressed) {
                    if (isX) {
                        if (zoomStartX == 0) zoomStartX = e.GetPosition(this).X;
                        if (e.GetPosition(this).X > zoomStartX) zoomX += 0.5;
                        else {
                            if (Math.Round(zoomX, 2) > 0.1) zoomX -= 0.5;
                        }
                    }
                    else {
                        if (zoomStartY == 0) zoomStartY = e.GetPosition(this).Y;
                        if (e.GetPosition(this).Y > zoomStartY) zoomY += 0.5;
                        else {
                            if (Math.Round(zoomY, 2) > 0.1) zoomY -= 0.5;
                        }
                    }
                    InvalidateMeasure();
                    InvalidateVisual();
                }
                if (e.LeftButton == MouseButtonState.Released)
                    zoomStartX = zoomStartY = 0;
            }
        }
        protected override Visual GetVisualChild(int index) => children[index];
        protected override int VisualChildrenCount => children.Count;
    }
}
