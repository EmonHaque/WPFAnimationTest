﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WPFCanvas.UIs
{
    public class Circle : FrameworkElement
    {
        public int value;
        double leftBound, rightBound, radius;
        Path path;
        EllipseGeometry circle;
        RadialGradientBrush radialBrush;
        GradientStop firstStop;
        DoubleAnimation gradientAnim, scaleAnim;

        public event Action<Circle> OnPointerOver;
        public event Action OnPointerAway;

        public Circle(int value) {
            this.value = value;
            radius = 8;
            firstStop = new GradientStop(Colors.LightBlue, 0);
            radialBrush = new RadialGradientBrush() {
                GradientOrigin = new Point(0.5, 0.5),
                GradientStops = {
                    firstStop,
                    new GradientStop(Color.FromArgb(100, 255, 0, 0), 1)
                }
            };
            circle = new EllipseGeometry() { RadiusX = radius, RadiusY = radius };
            path = new Path() {
                Fill = radialBrush,
                Data = circle
            };

            gradientAnim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(1),
                Duration = TimeSpan.FromSeconds(0.5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            scaleAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(1),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            RenderTransform = new ScaleTransform();
            Pointer.OnMoved += DetectOverlap;
            Loaded += appear;
        }

        void appear(object sender, RoutedEventArgs e) {
            var anim = new DoubleAnimation() {
                BeginTime = TimeSpan.FromSeconds(5),
                Duration = TimeSpan.FromSeconds(1),
                To = 0.5,
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
            RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }

        void DetectOverlap(double x) {
            if (x != 0) {
                if (x >= leftBound && x <= rightBound) {
                    if (gradientAnim.To != 1) {
                        gradientAnim.To = scaleAnim.To = 1;
                        firstStop.BeginAnimation(GradientStop.OffsetProperty, gradientAnim);
                        RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnim);
                        RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnim);
                        OnPointerOver(this);
                    }
                }
                else {
                    if (gradientAnim.To == 1) {
                        gradientAnim.To = 0;
                        scaleAnim.To = 0.5;
                        firstStop.BeginAnimation(GradientStop.OffsetProperty, gradientAnim);
                        RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnim);
                        RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnim);
                        OnPointerAway();
                    }
                }
            }
        }

        public void SetCenter(Point center) {
            circle.Center = center;
            leftBound = center.X - radius;
            rightBound = center.X + radius;

            var transform = RenderTransform as ScaleTransform;
            transform.ScaleX = transform.ScaleY = 0;
            transform.CenterX = center.X;
            transform.CenterY = center.Y;

            InvalidateVisual();
        }

        protected override void OnRender(DrawingContext drawingContext) {
            drawingContext.DrawGeometry(radialBrush, null, path.Data);
        }
    }
}
