﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace WPFCanvas.UIs
{
    public class Slice : FrameworkElement
    {
        PathGeometry geometry, arcGeo;
        PathFigure figure;
        LineSegment line;
        ArcSegment arc;
        SolidColorBrush originalBrush, backgroundBrush;

        double cx, dx, cy, dy, radius, rotation;
        Point start, end;
        bool isLargeArc;
        DoubleAnimation scaleAndRotateAnim, translateXAnim, translateYAnim;
        ColorAnimation backgroundAnim;

        public int value;

        public Slice(SolidColorBrush brush, int value) {
            this.value = value;
            originalBrush = brush;
            backgroundBrush = new SolidColorBrush(originalBrush.Color);

            line = new LineSegment();
            arc = new ArcSegment() { SweepDirection = SweepDirection.Clockwise };
            figure = new PathFigure() {
                IsClosed = true,
                Segments = { line, arc }
            };
            geometry = new PathGeometry() { Figures = { figure } };
            initAnimations();
            Loaded += animate;
        }

        void initAnimations() {
            var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
            scaleAndRotateAnim = new DoubleAnimation() {
                From = 0,
                Duration = TimeSpan.FromSeconds(5),
                EasingFunction = ease
            };
            translateXAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(2),
                EasingFunction = ease
            };
            translateYAnim = new DoubleAnimation() {
                Duration = TimeSpan.FromSeconds(2),
                EasingFunction = ease
            };
            backgroundAnim = new ColorAnimation() {
                Duration = TimeSpan.FromSeconds(2),
                EasingFunction = ease
            };
        }

        void animate(object sender, RoutedEventArgs e) {
            arcGeo.Freeze();
            var anim = new PointAnimationUsingPath() {
                PathGeometry = arcGeo,
                Duration = TimeSpan.FromSeconds(5),
                FillBehavior = FillBehavior.Stop
            };

            RenderTransform = new TransformGroup() {
                Children = {
                    new ScaleTransform(1, 1) {
                        CenterX = cx,
                        CenterY = cy
                    },
                    new RotateTransform(360) {
                        CenterX = cx,
                        CenterY = cy
                    }
                }
            };
            arc.BeginAnimation(ArcSegment.PointProperty, anim);

            var scale = (RenderTransform as TransformGroup).Children[0];
            var rotate = (RenderTransform as TransformGroup).Children[1];
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAndRotateAnim);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAndRotateAnim);
            rotate.BeginAnimation(RotateTransform.AngleProperty, scaleAndRotateAnim);
            rotate.Changed += updateRotation;
        }

        void updateRotation(object sender, EventArgs e) {
            rotation = (sender as RotateTransform).Angle;
            if (rotation == 360)
                RenderTransform = new TranslateTransform(0, 0);
        }

        public void SetParameters(double cx, double cy, double radius, double startAngle, double sweepAngle, bool isLargeArc) {
            this.cx = cx;
            this.cy = cy;
            this.radius = radius;
            this.isLargeArc = isLargeArc;
            start = new Point(cx + radius * Math.Cos(startAngle), cy + radius * Math.Sin(startAngle));
            end = new Point(cx + radius * Math.Cos(startAngle + sweepAngle), cy + radius * Math.Sin(startAngle + sweepAngle));

            dx = Math.Cos(startAngle + sweepAngle / 2) * 10;
            dy = Math.Sin(startAngle + sweepAngle / 2) * 10;

            arcGeo = new PathGeometry() {
                Figures = {
                    new PathFigure() {
                        StartPoint = start,
                        Segments = {
                            new ArcSegment() {
                                SweepDirection = SweepDirection.Clockwise,
                                Size = new Size(radius, radius),
                                IsLargeArc = isLargeArc,
                                Point = end,
                            }
                        }
                    }
                }
            };

            Draw();
        }

        void Draw() {
            figure.StartPoint = new Point(cx, cy);
            line.Point = start;
            arc.Point = end;
            arc.Size = new Size(radius, radius);
            arc.IsLargeArc = isLargeArc;
        }

        protected override void OnRender(DrawingContext dc) {
            dc.DrawGeometry(backgroundBrush, null, geometry);
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            if (rotation < 360) return;
            var transform = RenderTransform as TranslateTransform;
            translateXAnim.By = dx - transform.X;
            translateYAnim.By = dy - transform.Y;
            
            RenderTransform.BeginAnimation(TranslateTransform.XProperty, translateXAnim);
            RenderTransform.BeginAnimation(TranslateTransform.YProperty, translateYAnim);

            backgroundAnim.To = Colors.Gray;
            backgroundBrush.BeginAnimation(SolidColorBrush.ColorProperty, backgroundAnim);
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            if (rotation < 360) return;
            var transform = RenderTransform as TranslateTransform;
            translateXAnim.By = -transform.X;
            translateYAnim.By = -transform.Y;
            
            RenderTransform.BeginAnimation(TranslateTransform.XProperty, translateXAnim);
            RenderTransform.BeginAnimation(TranslateTransform.YProperty, translateYAnim);

            backgroundAnim.To = originalBrush.Color;
            backgroundBrush.BeginAnimation(SolidColorBrush.ColorProperty, backgroundAnim);
        }
    }
}
