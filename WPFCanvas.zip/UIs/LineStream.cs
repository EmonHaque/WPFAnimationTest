﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace WPFCanvas.UIs
{
    public class LineStream : FrameworkElement
    {
        List<int> values;
        double height, spacing, lower, upper, tickWidth, labelWidth;
        StreamGeometry geometry, polygon;
        Pen pen;
        LinearGradientBrush polyBrush;
        DoubleAnimation polyColorAnim;
        
        public LineStream(List<int> values) {
            this.values = values;
            pen = new Pen() { Brush = Brushes.Black, Thickness = 2 };
            polyBrush = new LinearGradientBrush() {
                StartPoint = new Point(0.5, 0),
                EndPoint = new Point(0.5, 1),
                GradientStops = {
                    new GradientStop(){ Offset = 0, Color = Color.FromArgb(75, 0,0,100)},
                    new GradientStop(){ Offset = 0, Color = Colors.Transparent}
                }
            };
            geometry = new StreamGeometry();
            polygon = new StreamGeometry();

            polyColorAnim = new DoubleAnimation() {
                To = 1,
                BeginTime = TimeSpan.FromSeconds(5),
                Duration = TimeSpan.FromSeconds(5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
            };
            Loaded += animateLine;
        }

        void animateLine(object sender, RoutedEventArgs e) {  
            var pathAnim = new RectAnimation() {
                From = new Rect(0, 0, 0, height),
                Duration = TimeSpan.FromSeconds(5),
                EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
            };
            Clip.BeginAnimation(RectangleGeometry.RectProperty, pathAnim);
            polyBrush.GradientStops[0].BeginAnimation(GradientStop.OffsetProperty, polyColorAnim);
            polyBrush.GradientStops[1].BeginAnimation(GradientStop.OffsetProperty, polyColorAnim);
        }

        public void SetParameters(double width, double height, double lower, double upper, double tickWidth, double labelWidth) {          
            this.height = height;
            this.lower = lower;
            this.upper = upper;
            this.tickWidth = tickWidth;
            this.labelWidth = labelWidth;
            spacing = (width - tickWidth) / values.Count;
            Clip = new RectangleGeometry(new Rect(0, 0, width, height));
            InvalidateVisual();
        }

        protected override void OnRender(DrawingContext drawingContext) {
            var availableHeight = height / 10 * 9;
            var posHeight = availableHeight / (lower + upper) * upper;
            var negHeight = availableHeight - posHeight;

            geometry.Clear();
            polygon.Clear();
            var poly = polygon.Open();
            using(var geo = geometry.Open()) {
                double x = spacing;
                double y = values[0] < 0 ? negHeight - Math.Abs(values[0]) / lower * negHeight : values[0] / upper * posHeight + negHeight;

                poly.BeginFigure(new Point(x + tickWidth, negHeight + labelWidth), true, true);
                geo.BeginFigure(new Point(x + tickWidth, y + labelWidth), false, false);
                poly.LineTo(new Point(x + tickWidth, y + labelWidth), false, true);

                for (int i = 1; i < values.Count; i++) {
                    x += spacing;
                    y = values[i] < 0 ? negHeight - Math.Abs(values[i]) / lower * negHeight : values[i] / upper * posHeight + negHeight;
                    geo.LineTo(new Point(x + tickWidth, y + labelWidth), true, true);
                    poly.LineTo(new Point(x + tickWidth, y + labelWidth), true, true);
                }
                poly.LineTo(new Point(x + tickWidth, negHeight + labelWidth), true, true);
            }
            poly.Close();
            drawingContext.DrawGeometry(null, pen, geometry);
            drawingContext.DrawGeometry(polyBrush, null, polygon);
        }
    }
}
