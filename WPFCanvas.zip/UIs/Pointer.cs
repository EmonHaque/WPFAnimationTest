﻿using System;
using System.Windows;
using System.Windows.Media;

namespace WPFCanvas.UIs
{
    public class Pointer : UIElement
    {
        Pen pen;
        Point start, end;
        public static event Action<double> OnMoved;
        public Pointer() {
            pen = new Pen(Brushes.Black, 1) {
                DashStyle = DashStyles.DashDotDot,
                DashCap = PenLineCap.Round
            };
            start = new Point();
            end = new Point();
        }

        public void SetParameters(double x1, double y2, double labelWidth) {
            start.X = end.X = x1;
            start.Y = labelWidth;
            end.Y = y2;
            InvalidateVisual();
            OnMoved(x1);
        }

        protected override void OnRender(DrawingContext drawingContext) => drawingContext.DrawLine(pen, start, end);
    }
}
