﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WPFCanvas.Model;

namespace WPFCanvas.ViewModel
{
    class MainViewModel
    {
        string PathIcon = "PathIcon";
        string MaxLength = "MaxLength";
        string ErrorMessage = "ErrorMessage";

        public List<int> PieCollection { get; set; }
        public List<int> BarCollection { get; set; }
        public List<int> LineCollection { get; set; }
        public ObservableCollection<TestItem> ListItems { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        string myText;
        public string MyText {
            get { return myText; }
            set {
                myText = value;
                Debug.WriteLine(value);
                if (string.IsNullOrWhiteSpace(value)) {
                    App.Current.Resources[ErrorMessage] = "Required";
                }
                else if (value.Equals("my name", StringComparison.OrdinalIgnoreCase)) {
                    App.Current.Resources[ErrorMessage] = "Write something else!";
                }
                else if (value.Length == (int)App.Current.Resources[MaxLength]) {
                    App.Current.Resources[ErrorMessage] = "Max limit reached";
                }
                else {
                    App.Current.Resources[ErrorMessage] = string.Empty;
                }
            }
        }

        int? selected;
        public int? Selected {
            get { return selected; }
            set {
                selected = value;
                if (value == null) Debug.WriteLine("null");
                else Debug.WriteLine(value);
            }
        }
        DateTime? selectedDate;
        public DateTime? SelectedDate {
            get { return selectedDate; }
            set {
                selectedDate = value;
                Debug.WriteLine("Selected Date " + value);
            }
        }

        public MainViewModel() {
            App.Current.Resources.Add(PathIcon, "M12,19.2C9.5,19.2 7.29,17.92 6,16C6.03,14 10,12.9 12,12.9C14,12.9 17.97,14 18,16C16.71,17.92 14.5,19.2 12,19.2M12,5A3,3 0 0,1 15,8A3,3 0 0,1 12,11A3,3 0 0,1 9,8A3,3 0 0,1 12,5M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z");
            App.Current.Resources.Add(ErrorMessage, "");
            App.Current.Resources.Add(MaxLength, 10);

            BarCollection = new();
            PieCollection = new();
            LineCollection = new();
            ListItems = new();

            Random ran = new();
            for (int i = 0; i < 5; i++)
                PieCollection.Add(ran.Next(100, 400));
            for (int i = 0; i < 20; i++)
                BarCollection.Add(ran.Next(-100, 200));

            for (int i = 0; i < 20; i++)
                LineCollection.Add(ran.Next(50, 200));

            char[] array = { 'A', 'B', 'C', 'D', 'E' };
            var temp = new List<TestItem>();
            for (int i = 0; i < 30; i++) {
                var item = new TestItem() {
                    Index = i,
                    Text = array[ran.Next(0, array.Length)] + " sadfsdf sdasd " + i
                };
                temp.Add(item);
            }
            ListItems = new(temp.OrderBy(x => x.Text));
        }

        void AddItem(object sender, RoutedEventArgs e) {
            ListItems.Insert(0, new TestItem() { Index = 0, Text = "A New" });
        }

        void RemoveItem(object sender, RoutedEventArgs e) {
            ListItems.RemoveAt(0);
        }
    }
}
