﻿using System;
using System.Collections;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    public class ACanvas : Panel
    {
        #region mess
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }

        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(ACanvas), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as ACanvas;
            for (int i = 0; i < 10; i++) {
                var line = new Line() {
                    StrokeThickness = 1,
                    Stroke = Brushes.LightBlue,
                    IsHitTestVisible = false
                };
                o.Children.Add(line);
                line.Loaded += o.animateLines;

                var tick = new TextBlock() {
                    HorizontalAlignment = HorizontalAlignment.Right,
                    RenderTransform = new TransformGroup() {
                        Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                    },
                    IsHitTestVisible = false
                };
                o.Children.Add(tick);
                tick.Loaded += o.animateTicks;
            }
            foreach (int height in o.ItemSource) {
                var rect = new Border() {
                    Height = height,
                    Background = o.brush,
                    BorderBrush = Brushes.Black,
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(0, 0, 20, 20)
                };
                o.Children.Add(rect);
                rect.Loaded += o.animateBorder;

                var label = new Label() {
                    Content = height,
                    IsHitTestVisible = false,
                    VerticalContentAlignment = VerticalAlignment.Center,
                    HorizontalContentAlignment = HorizontalAlignment.Right,
                    RenderTransform = new TransformGroup() {
                        Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
                    }
                };
                o.Children.Add(label);
                label.Loaded += o.animateLabels;
            }
        }
        #endregion
        // Any auto property of a "Control" could've been a DependencyProperty and had an associalted callback!

        SolidColorBrush brush, highlight;
        TextBlock block;
        Popup pop;
        Border selected;
        DoubleAnimation borderScaleAnim, popOpacityAnim, popTranslateAnim;
        ColorAnimation borderColorAnim;
        DropShadowEffect effect;

        public ACanvas() {
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
            brush = Brushes.Gray;
            highlight = Brushes.LightBlue;

            initPopup();
            initPopupAnimations();
            initBorderAnimations();
            effect = new DropShadowEffect() { BlurRadius = 10, Direction = 90 };
        }

        void initPopup() {
            block = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            pop = new Popup() {
                AllowsTransparency = true,
                Child = new Border() {
                    Child = block,
                    CornerRadius = new CornerRadius(20),
                    Padding = new Thickness(5),
                    BorderBrush = Brushes.Black,
                    Background = Brushes.LightBlue,
                    BorderThickness = new Thickness(1)
                },
                Placement = PlacementMode.Center
            };
            pop.Opened += animatePopup;
        }

        void initPopupAnimations() {
            var duration = TimeSpan.FromSeconds(1);
            var easing = new CubicEase() { EasingMode = EasingMode.EaseIn };
            popOpacityAnim = new DoubleAnimation() {
                From = 0,
                Duration = duration,
                EasingFunction = easing
            };
            popTranslateAnim = new DoubleAnimation() {
                From = 20,
                Duration = duration,
                EasingFunction = easing
            };
            pop.Child.RenderTransform = new TranslateTransform(0, 0);
        }

        void initBorderAnimations() {
            var duration = TimeSpan.FromSeconds(5);
            var easing = new QuadraticEase() { EasingMode = EasingMode.EaseInOut };
            borderScaleAnim = new DoubleAnimation() {
                From = 0,
                Duration = duration,
                EasingFunction = easing
            };

            borderColorAnim = new ColorAnimation() {
                From = Colors.Transparent,
                To = Colors.Gray,
                Duration = duration,
                EasingFunction = easing,
            };
        }

        void animateBorder(object sender, RoutedEventArgs e) {
            var rect = e.Source as Border;
            var brush = new SolidColorBrush();
            rect.Background = brush;
            rect.RenderTransform = new ScaleTransform(1, 1, rect.Width / 2, 0);

            rect.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, borderScaleAnim);
            rect.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, borderScaleAnim);
            brush.BeginAnimation(SolidColorBrush.ColorProperty, borderColorAnim);
        }

        void animatePopup(object sender, EventArgs e) {
            pop.Child.RenderTransform.BeginAnimation(TranslateTransform.YProperty, popTranslateAnim);
            pop.Child.BeginAnimation(Border.OpacityProperty, popOpacityAnim);
        }

        void animateLabels(object sender, RoutedEventArgs e) {
            var label = sender as Label;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(4.5)),
                    new LinearDoubleKeyFrame(90, TimeSpan.FromSeconds(5.5))
                }
            };
            var transform = (label.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(RotateTransform.AngleProperty, anim);
        }

        void animateTicks(object sender, RoutedEventArgs e) {
            var tick = sender as TextBlock;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(-30, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(-30, TimeSpan.FromSeconds(4)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(4.5)),
                }
            };
            var transform = (tick.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(TranslateTransform.XProperty, anim);
        }

        void animateLines(object sender, RoutedEventArgs e) {
            var line = sender as Line;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(ActualHeight - line.Y1+15, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(ActualHeight - line.Y1+15, TimeSpan.FromSeconds(2)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(4)),
                }
            };
            line.RenderTransform = new TranslateTransform(0, 0);
            line.RenderTransform.BeginAnimation(TranslateTransform.YProperty, anim);
        }

        protected override Size ArrangeOverride(Size arrangeSize) {
            var space = 10d;
            var labelSpace = 10d;
            var labelHeight = 30d;
            var textSpace = 20d;

            var rects = InternalChildren.OfType<Border>().Count();
            var width = (arrangeSize.Width - textSpace - space * rects) / rects;
            var lineSpace = (arrangeSize.Height - labelHeight) / 10;
            var y = labelHeight;
            var textY = labelHeight;

            foreach (UIElement item in InternalChildren) {
                if (item is Border) {
                    (item as Border).Width = width;
                    item.Measure(arrangeSize);
                    item.Arrange(new Rect(new Point(space + textSpace, labelHeight), item.DesiredSize));
                    space = space + width + 10;
                }
                else if (item is Line) {
                    var line = item as Line;
                    line.X1 = 0;
                    line.X2 = arrangeSize.Width;
                    line.Y1 = line.Y2 = y;
                    item.Measure(arrangeSize);
                    item.Arrange(new Rect(item.DesiredSize));
                    y += lineSpace;
                }
                else if (item is TextBlock) {
                    var block = item as TextBlock;
                    block.Text = "Test";
                    block.Measure(arrangeSize);
                    block.Arrange(new Rect(new Point(0, textY + block.DesiredSize.Height), block.DesiredSize));
                    textY += lineSpace;
                }
                else {
                    var label = item as Label;
                    label.Width = labelHeight;
                    label.Height = width;
                    label.Measure(arrangeSize);
                    label.Arrange(new Rect(new Point(labelSpace + textSpace, 0), label.DesiredSize));
                    labelSpace = labelSpace + width + 10;
                }

            }
            return arrangeSize;
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            var position = e.GetPosition(this);
            foreach (var item in Children.OfType<Border>()) {
                if (item.IsMouseOver) {
                    selected = item;
                    selected.Background = highlight;
                    selected.Effect = effect;
                    block.Text = selected.Height.ToString();
                    pop.PlacementTarget = selected;
                    pop.VerticalOffset = item.Height / 2 + 20;
                    pop.IsOpen = true;
                    break;
                }
            }
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            selected.Background = brush;
            selected.Effect = null;
            pop.IsOpen = false;
        }
    }
}
