﻿using System;
using System.Collections;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace WPFCanvas.CustomControls
{
    public class ACanvas : Panel
    {
        #region mess
        public IEnumerable ItemSource {
            get { return (IEnumerable)GetValue(ItemSourceProperty); }
            set { SetValue(ItemSourceProperty, value); }
        }

        public static readonly DependencyProperty ItemSourceProperty =
            DependencyProperty.Register("ItemSource", typeof(IEnumerable), typeof(ACanvas), new PropertyMetadata(null, onSourceChanged));

        static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = d as ACanvas;
            foreach (int height in o.ItemSource) {
                o.addBorder(height);
                o.addLabel(height);
                if (height > o.maxValue) o.maxValue = height;
                if (height < o.minValue) o.minValue = height;
            }

            var min = o.minValue < 0 ? o.minValue - 10 : 0;
            var step = min < 0 ? (o.maxValue + 10 + Math.Abs(min)) / 9 : (o.maxValue + 10) / 9;
            double current = min;

            for (int i = 0; i < 10; i++) {
                o.addLine();
                o.addTick(current);
                current += step;
            }
        }
        #endregion
        // Any auto property of a "Control" could've been a DependencyProperty and had an associalted callback!

        SolidColorBrush positiveBrush, negativeBrush, highlight;
        TextBlock block;
        Popup pop;
        Border selected;
        DoubleAnimation borderScaleAnim, popOpacityAnim, popTranslateAnim;
        ColorAnimation borderColorAnim;
        DropShadowEffect effect;
        double minValue, maxValue, horizontalOffset;

        public ACanvas() {
            LayoutTransform = new ScaleTransform() { ScaleY = -1 };
            positiveBrush = Brushes.Gray;
            negativeBrush = Brushes.Maroon;
            highlight = Brushes.LightBlue;

            initPopup();
            initPopupAnimations();
            effect = new DropShadowEffect() { BlurRadius = 10, Direction = 90 };
        }

        void addBorder(int height) {
            var rect = new Border() {
                Tag = height,
                Background = positiveBrush,
                BorderBrush = Brushes.Black,
                BorderThickness = new Thickness(1),
                CornerRadius = height > 0 ? new CornerRadius(0, 0, 20, 20) : new CornerRadius(20, 20, 0, 0)
            };
            SetZIndex(rect, 1);
            Children.Add(rect);
            rect.Loaded += animateBorder;
        }

        void addLabel(int height) {
            var label = new Label() {
                Content = height,
                IsHitTestVisible = false,
                VerticalContentAlignment = VerticalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
                }
            };
            Children.Add(label);
            label.Loaded += animateLabels;
        }

        void addLine() {
            var line = new Line() {
                StrokeThickness = 1,
                Stroke = Brushes.LightBlue,
                IsHitTestVisible = false
            };
            SetZIndex(line, 0);
            Children.Add(line);
            line.Loaded += animateLines;
        }

        void addTick(double value) {
            var tick = new TextBlock() {
                Text = value.ToString("N2"),
                HorizontalAlignment = HorizontalAlignment.Right,
                RenderTransform = new TransformGroup() {
                    Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
                },
                IsHitTestVisible = false
            };
            Children.Add(tick);
            tick.Loaded += animateTicks;
        }

        void initPopup() {
            block = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            pop = new Popup() {
                AllowsTransparency = true,
                Child = new Border() {
                    Child = block,
                    CornerRadius = new CornerRadius(20),
                    Padding = new Thickness(5),
                    BorderBrush = Brushes.Black,
                    Background = Brushes.LightBlue,
                    BorderThickness = new Thickness(1)
                },
                Placement = PlacementMode.Center
            };
            pop.Opened += animatePopup;
        }

        void initPopupAnimations() {
            var duration = TimeSpan.FromSeconds(1);
            var easing = new CubicEase() { EasingMode = EasingMode.EaseIn };
            popOpacityAnim = new DoubleAnimation() {
                From = 0,
                Duration = duration,
                EasingFunction = easing
            };
            popTranslateAnim = new DoubleAnimation() {
                Duration = duration,
                EasingFunction = easing
            };
            pop.Child.RenderTransform = new TranslateTransform(0, 0);
        }

        void animateBorder(object sender, RoutedEventArgs e) {
            var rect = e.Source as Border;
            var height = (int)rect.Tag;
            var brush = new SolidColorBrush();
            rect.Background = brush;

            var duration = TimeSpan.FromSeconds(5);
            var easing = new QuadraticEase() { EasingMode = EasingMode.EaseInOut };
            borderScaleAnim = new DoubleAnimation() {
                From = 0,
                Duration = duration,
                EasingFunction = easing
            };

            borderColorAnim = new ColorAnimation() {
                From = Colors.Transparent,
                To = height > 0 ? Colors.Gray : Colors.Maroon,
                Duration = duration,
                EasingFunction = easing,
            };

            rect.RenderTransform = height > 0 ? new ScaleTransform(1, 1, rect.Width / 2, 0) : new ScaleTransform(1, 1, rect.Width / 2, rect.Height);

            rect.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, borderScaleAnim);
            rect.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, borderScaleAnim);
            brush.BeginAnimation(SolidColorBrush.ColorProperty, borderColorAnim);
        }

        void animatePopup(object sender, EventArgs e) {
            pop.Child.RenderTransform.BeginAnimation(TranslateTransform.YProperty, popTranslateAnim);
            pop.Child.BeginAnimation(Border.OpacityProperty, popOpacityAnim);
        }

        void animateLabels(object sender, RoutedEventArgs e) {
            var label = sender as Label;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(4.5)),
                    new LinearDoubleKeyFrame(90, TimeSpan.FromSeconds(5.5))
                }
            };
            var transform = (label.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(RotateTransform.AngleProperty, anim);
        }

        void animateTicks(object sender, RoutedEventArgs e) {
            var tick = sender as TextBlock;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(-30 - horizontalOffset, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(-30 - horizontalOffset, TimeSpan.FromSeconds(4)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(4.5)),
                }
            };
            var transform = (tick.RenderTransform as TransformGroup).Children[1];
            transform.BeginAnimation(TranslateTransform.XProperty, anim);
        }

        void animateLines(object sender, RoutedEventArgs e) {
            var line = sender as Line;
            var anim = new DoubleAnimationUsingKeyFrames() {
                KeyFrames = {
                    new LinearDoubleKeyFrame(ActualHeight - line.Y1+15, TimeSpan.FromSeconds(0)),
                    new LinearDoubleKeyFrame(ActualHeight - line.Y1+15, TimeSpan.FromSeconds(2)),
                    new LinearDoubleKeyFrame(0, TimeSpan.FromSeconds(4)),
                }
            };
            line.RenderTransform = new TranslateTransform(0, 0);
            line.RenderTransform.BeginAnimation(TranslateTransform.YProperty, anim);
        }

        protected override Size ArrangeOverride(Size arrangeSize) {
            var testTick = new TextBlock() { Text = (maxValue + 10).ToString("N2") };
            testTick.Measure(arrangeSize);

            var space = 10d;
            var labelSpace = 10d;
            var labelHeight = 50d; // measure ad set
            var tickSpace = horizontalOffset = testTick.DesiredSize.Width;

            var rects = InternalChildren.OfType<Border>().Count();
            var width = (arrangeSize.Width - tickSpace - space * rects) / rects;
            var lineSpace = (arrangeSize.Height - labelHeight) / 10;
            var y = labelHeight;
            var textY = labelHeight;

            var upperBound = maxValue + 10;
            var lowerBound = minValue < 0 ? Math.Abs(minValue - 10) : 0;
            var availableHeight = (arrangeSize.Height - labelHeight) / 10 * 9;

            var negHeight = availableHeight / (upperBound + lowerBound) * lowerBound;
            var posHeight = availableHeight - negHeight;

            foreach (UIElement item in InternalChildren) {
                if (item is Border) {
                    var rect = item as Border;
                    rect.Width = width;

                    var givenHeight = (int)rect.Tag;
                    if(givenHeight < 0) rect.Height = Math.Abs(givenHeight) / lowerBound * (availableHeight - posHeight);
                    else rect.Height = givenHeight / upperBound * (availableHeight - negHeight);

                    rect.Measure(arrangeSize);
                    if (givenHeight < 0)
                        rect.Arrange(new Rect(new Point(space + tickSpace, labelHeight + negHeight - rect.Height), rect.DesiredSize));
                    else
                        rect.Arrange(new Rect(new Point(space + tickSpace, labelHeight + negHeight), rect.DesiredSize));
                    space = space + width + 10;
                }
                else if (item is Line) {
                    var line = item as Line;
                    line.X1 = 0;
                    line.X2 = arrangeSize.Width;
                    line.Y1 = line.Y2 = y;
                    item.Measure(arrangeSize);
                    item.Arrange(new Rect(item.DesiredSize));
                    y += lineSpace;
                }
                else if (item is TextBlock) {
                    var block = item as TextBlock;
                    block.Measure(arrangeSize);
                    block.Arrange(new Rect(new Point(0, textY + block.DesiredSize.Height), block.DesiredSize));
                    textY += lineSpace;
                }
                else {
                    var label = item as Label;
                    label.Width = labelHeight;
                    label.Height = width;
                    label.Measure(arrangeSize);
                    label.Arrange(new Rect(new Point(labelSpace + tickSpace, 0), label.DesiredSize));
                    labelSpace = labelSpace + width + 10;
                }

            }
            return arrangeSize;
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            foreach (var item in Children.OfType<Border>()) {
                if (item.IsMouseOver) {
                    selected = item;
                    var height = (int)selected.Tag;
                    selected.Background = highlight;
                    selected.Effect = effect;
                    block.Text = ((int)selected.Tag).ToString();
                    if(height < 0) {
                        pop.VerticalOffset = -item.Height / 2 - 20;
                        popTranslateAnim.From = -20;
                    }
                    else {
                        pop.VerticalOffset = item.Height / 2 + 20;
                        popTranslateAnim.From = 20;
                    }
                    pop.PlacementTarget = selected;
                    
                    pop.IsOpen = true;
                    break;
                }
            }
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            var height = (int)selected.Tag;
            selected.Background = height > 0 ? positiveBrush : negativeBrush;
            selected.Effect = null;
            pop.IsOpen = false;
        }
    }
}
