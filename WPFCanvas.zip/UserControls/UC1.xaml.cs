﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFCanvas.CustomControls;

namespace WPFCanvas.UserControls
{
    /// <summary>
    /// Interaction logic for UC1.xaml
    /// </summary>
    public partial class UC1 : UserControl, IHaveIcon
    {
        public string Icon { get; set; }
        public UC1() {
            InitializeComponent();
            Icon = "M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M11,7A2,2 0 0,0 9,9V17H11V13H13V17H15V9A2,2 0 0,0 13,7H11M11,9H13V11H11V9Z";
        }

        void Button_Click(object sender, RoutedEventArgs e) {
            var modal = new PopModal() {
                Title = "A Message Box",
                Message = "A Message  A Message A Message A Message"
            };
            if (modal.ShowDialog().Value) {
                Debug.WriteLine("Ok clicked");
            }
            else {
                Debug.WriteLine("Cancelled");
            }
        }
    }
}
